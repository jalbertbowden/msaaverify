Namespace MsaaVerify

    Public MustInherit Class MsaaVerifyException : Inherits Exception

        Public Sub New(ByVal message As String)
            MyBase.New(message)
        End Sub

        Public Sub New(ByVal message As String, ByVal innerException As Exception)
            MyBase.New(message, innerException)
        End Sub
    End Class

    Public Class CannotUpdateBugTemplateFormException : Inherits MsaaVerifyException
        Public Sub New(ByVal message As String)
            MyBase.New(message)
        End Sub

        Public Sub New(ByVal message As String, ByVal innerException As Exception)
            MyBase.New(message, innerException)
        End Sub
    End Class

    Public Class CannotCreateAccessibleObjectException : Inherits MsaaVerifyException
        Public Sub New(ByVal message As String)
            MyBase.New(message)
        End Sub

        Public Sub New(ByVal message As String, ByVal innerException As Exception)
            MyBase.New(message, innerException)
        End Sub
    End Class

    Public Class ChildNotFoundException : Inherits MsaaVerifyException
        Public Sub New(ByVal message As String)
            MyBase.New(message)
        End Sub
    End Class

    Public Class UnknownWinControlException : Inherits MsaaVerifyException
        Public Sub New(ByVal message As String)
            MyBase.New(message)
        End Sub
    End Class

    Public Class StatusBarPanelTextException : Inherits MsaaVerifyException
        Public Sub New(ByVal message As String)
            MyBase.New(message)
        End Sub
    End Class

    Public Class ApiCallFailedException : Inherits MsaaVerifyException
        Public Sub New(ByVal message As String)
            MyBase.New(message)
        End Sub
    End Class

#Region "Msaa Exceptions"

    Public Class Msaa

        Public Class ChildException : Inherits MsaaVerifyException
            Public Sub New(ByVal message As String)
                MyBase.New(message)
            End Sub
            Public Sub New(ByVal message As String, ByVal innerException As Exception)
                MyBase.New(message, innerException)
            End Sub
        End Class

        Public Class ChildCountException : Inherits MsaaVerifyException
            Public Sub New(ByVal message As String)
                MyBase.New(message)
            End Sub
            Public Sub New(ByVal message As String, ByVal innerException As Exception)
                MyBase.New(message, innerException)
            End Sub
        End Class

        Public Class DescriptionException : Inherits MsaaVerifyException
            Public Sub New(ByVal message As String)
                MyBase.New(message)
            End Sub
            Public Sub New(ByVal message As String, ByVal innerException As Exception)
                MyBase.New(message, innerException)
            End Sub
        End Class

        Public Class DefaultActionException : Inherits MsaaVerifyException
            Public Sub New(ByVal message As String)
                MyBase.New(message)
            End Sub
            Public Sub New(ByVal message As String, ByVal innerException As Exception)
                MyBase.New(message, innerException)
            End Sub
        End Class

        Public Class KeyboardShortcutException : Inherits MsaaVerifyException
            Public Sub New(ByVal message As String)
                MyBase.New(message)
            End Sub
            Public Sub New(ByVal message As String, ByVal innerException As Exception)
                MyBase.New(message, innerException)
            End Sub
        End Class

        Public Class NameException : Inherits MsaaVerifyException
            Public Sub New(ByVal message As String)
                MyBase.New(message)
            End Sub
            Public Sub New(ByVal message As String, ByVal innerException As Exception)
                MyBase.New(message, innerException)
            End Sub
        End Class

        Public Class ParentException : Inherits MsaaVerifyException
            Public Sub New(ByVal message As String)
                MyBase.New(message)
            End Sub
            Public Sub New(ByVal message As String, ByVal innerException As Exception)
                MyBase.New(message, innerException)
            End Sub
        End Class

        Public Class RoleException : Inherits MsaaVerifyException
            Public Sub New(ByVal message As String)
                MyBase.New(message)
            End Sub
            Public Sub New(ByVal message As String, ByVal innerException As Exception)
                MyBase.New(message, innerException)
            End Sub
        End Class

        Public Class StateException : Inherits MsaaVerifyException
            Public Sub New(ByVal message As String)
                MyBase.New(message)
            End Sub
            Public Sub New(ByVal message As String, ByVal innerException As Exception)
                MyBase.New(message, innerException)
            End Sub
        End Class

        Public Class ValueException : Inherits MsaaVerifyException
            Public Sub New(ByVal message As String)
                MyBase.New(message)
            End Sub
            Public Sub New(ByVal message As String, ByVal innerException As Exception)
                MyBase.New(message, innerException)
            End Sub
        End Class

        Public Class ObjectIsElementException : Inherits MsaaVerifyException
            Public Sub New()
                MyBase.New("Cannot access Child property since this object is an element")
            End Sub
        End Class

        Public Class FailedToConvertAccessibleObjectFromPoint : Inherits MsaaVerifyException
            Public Sub New(ByVal message As String)
                MyBase.New(message)
            End Sub
        End Class
    End Class
#End Region

End Namespace