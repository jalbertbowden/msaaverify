Imports System
Imports System.Windows.Forms
Imports Accessibility
Imports System.Drawing

Namespace MyCustomControls
    Public Class MyStaticText
        Inherits Button

        Public Sub New()
            ' Make the check box appear like a toggle button.
            ' Center the text on the button.
            Me.Text = "Inaccessible Static Text"
        End Sub

        ' Create an instance of the AccessibleObject 
        ' defined for the 'MyStaticText' control 
        Protected Overrides Function CreateAccessibilityInstance() _
          As AccessibleObject
            Return New MyStaticTextAccessibleObject(Me)
        End Function
    End Class

    ' Accessible object for use with the 'MyStaticText' control.
    Friend Class MyStaticTextAccessibleObject
        Inherits Control.ControlAccessibleObject

        Public Sub New(ByVal owner As MyStaticText)
            MyBase.New(owner)
        End Sub

        Public Overloads Function getHelpTopic() As String
            Return "http://www.microsoft.com"
        End Function

        Public Overrides ReadOnly Property Help() As String
            Get
                Return "http://www.microsoft.com"
            End Get
        End Property

        Public Overrides ReadOnly Property DefaultAction() As String
            Get
                ' Return the DefaultAction based upon 
                ' the state of the control. 
                Throw New System.Runtime.InteropServices.COMException("", &H80020003)
            End Get
        End Property

        Public Overrides ReadOnly Property Description() As String
            Get
                Throw New System.Runtime.InteropServices.COMException("", &H80020001)
            End Get
        End Property

        Public Overrides ReadOnly Property KeyboardSHortcut() As String
            Get
                Throw New System.Runtime.InteropServices.COMException("", &H80020003)
            End Get
        End Property

        Public Overrides Property Name() As String
            Get
                Throw New System.Runtime.InteropServices.COMException("", &H80020003)
            End Get

            Set(ByVal Value As String)
                MyBase.Name = Value
            End Set
        End Property

        Public Overrides ReadOnly Property Role() As AccessibleRole
            Get
                Return AccessibleRole.StaticText
            End Get
        End Property

        Public Overrides ReadOnly Property State() As AccessibleStates
            Get
                Throw New System.Runtime.InteropServices.COMException("", &H80020003)
            End Get
        End Property

        Public Overrides Property Value() As String
            Get
                Throw New System.Runtime.InteropServices.COMException("", &H80020003)
            End Get
            Set(ByVal Value As String)
                Me.Value = Value
            End Set
        End Property

    End Class
End Namespace
