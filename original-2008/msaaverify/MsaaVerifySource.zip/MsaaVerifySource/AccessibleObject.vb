Imports Accessibility
Imports System.Text
Imports System.Runtime.InteropServices

Namespace MsaaVerify

#Region "Enums"
    ' determines whether the object is a list view or a list box
    Public Enum ListType
        Neither = 0
        ListBox = 1
        ListView = 2
    End Enum

    ' determines what win32 state the checkbox is in
    Public Enum CheckBoxState
        UnChecked = 0
        Checked = 1
        InDeterminate = 2
    End Enum

    ' represents the possible combinations of states a control can be in
    ' these are taken from oleacc.h
    Public Enum MsaaStates
        Unavailable = &H1
        Selected = &H2
        Focused = &H4
        Pressed = &H8
        Checked = &H10
        Mixed = &H20
        [ReadOnly] = &H40
        HotTracked = &H80
        [Default] = &H100
        Expanded = &H200
        Collapsed = &H400
        Busy = &H800
        Floating = &H1000
        Marqueed = &H2000
        Animated = &H4000
        Invisible = &H8000
        OffScreen = &H10000
        Sizeable = &H20000
        Moveable = &H40000
        SelfVoicing = &H80000
        Focusable = &H100000
        Selectable = &H200000
        Linked = &H400000
        Traversed = &H800000
        MultiSelectable = &H1000000
        ExtSelectable = &H2000000
        AlertLow = &H4000000
        AlertMedium = &H8000000
        AlertHigh = &H10000000
        Valid = &H1FFFFFFF
        HasPopUp = &H40000000
        [Protected] = &H20000000
        Normal = 0
    End Enum

    ' represents the type of control or role
    ' these are taken from oleacc.h
    Public Enum MsaaRoles
        TitleBar = &H1
        MenuBar = &H2
        ScrollBar = &H3
        Grip = &H4
        Sound = &H5
        Cursor = &H6
        Caret = &H7
        Alert = &H8
        Window = &H9
        Client = &HA
        MenuPopup = &HB
        MenuItem = &HC
        MenuButton = &H39
        ToolTip = &HD
        Application = &HE
        Document = &HF
        Pane = &H10
        Chart = &H11
        Dialog = &H12
        Border = &H13
        Grouping = &H14
        Separator = &H15
        ToolBar = &H16
        StatusBar = &H17
        Table = &H18
        ColumnHeader = &H19
        RowHeader = &H1A
        Column = &H1B
        Row = &H1C
        Cell = &H1D
        Link = &H1E
        HelpBalloon = &H1F
        Character = &H20
        List = &H21
        ListItem = &H22
        Outline = &H23
        OutlineItem = &H24
        PageTab = &H25
        PropertyPage = &H26
        Indicator = &H27
        Graphic = &H28
        StaticText = &H29
        Text = &H2A
        PushButton = &H2B
        CheckButton = &H2C
        RadioButton = &H2D
        ComboBox = &H2E
        DropList = &H2F
        ProgressBar = &H30
        Dial = &H31
        HotKeyField = &H32
        Slider = &H33
        SpinButton = &H34
        Diagram = &H35
        Animation = &H36
        Equation = &H37
        ButtonDropDown = &H38
        ButtonMenu = &H39
        ButtonDropDownGrid = &H3A
        Whitespace = &H3B
        PageTabList = &H3C
        Clock = &H3D
    End Enum

#End Region

    Public Class AccessibleObject

#Region "Private Const and Variables"
        ' the accessible object's interface
        Private m_msaa As Accessibility.IAccessible
        ' the accessible object's child id 
        Private m_childId As Integer
        ' the hwnd for the accessible object's control
        Private m_hwnd As IntPtr

        ' used for string builder
        Private Const MaxRole As Integer = 128
        ' used for string builder
        Private Const MaxState As Integer = 256
        ' if it doesn't have a child or is the parent object, the id is 0
        Private Const ChildId_Self As Integer = &H0
        ' we're only interested in the client, not the window or native object model or whatever else
        Private Const MsaaObjectIdClient As Integer = &HFFFFFFFC
#End Region

#Region "Constructors"
        ' Create an ActiveAccessibility object from point
        Public Sub New(ByVal x As Integer, ByVal y As Integer)
            Try
                Dim childIdTemp As Object
                NativeMethods.AccessibleObjectFromPoint(lx:=x, ly:=y, ppoleAcc:=m_msaa, pvarElement:=childIdTemp)
                m_childId = childIdTemp
            Catch ex As Exception
                Throw New Msaa.FailedToConvertAccessibleObjectFromPoint(ex.Message)
            End Try
        End Sub

        ' Create an ActiveAccessibility object from an existing IAccessible interface
        Public Sub New(ByVal accessibleObject As IAccessible)
            m_msaa = accessibleObject
            m_childId = ChildID
        End Sub

        ' Create an ActiveAccessibility object from an existing IAccessible interface for a specified child object
        Public Sub New(ByVal accessibleObject As IAccessible, ByVal childID As Integer)
            m_msaa = accessibleObject
            m_childId = childID
        End Sub

        ' Create an ActiveAccessibility object from a known hwnd
        Public Sub New(ByVal windowHandle As IntPtr)
            'This defines the riid for the iaccessible interface
            Dim riidGUID As New Guid("{618736E0-3C3D-11CF-810C-00AA00389B71}")

            ' We pass in MSAA Object ID client, since we're most likely not going to use Office Object Model
            ' If we were to use the Office Object Model, we would pass in MsaaObjectID.NativeOM
            ' read more at http://msdn.microsoft.com/library/en-us/msaa/msaaccrf_2r7b.asp
            NativeMethods.AccessibleObjectFromWindow(windowHandle, MsaaObjectIdClient, riidGUID, m_msaa)
            Me.SetHwnd(windowHandle)
            m_childId = Me.ChildId_Self ' AccessibleObjectFromWindow returns the object itself and not one of its simple elements or children
        End Sub
#End Region

#Region "IAccessible Properties and Methods Used"

        ' get a pointer to the requested child object, if possible
        Public ReadOnly Property Child(ByVal index As Integer) As AccessibleObject
            Get
                If Me.ChildCount > 0 Then
                    If index < 0 Or index >= Me.ChildCount Then
                        Throw New ChildNotFoundException("Index provided is less than 0 or greater than the number of children")
                    End If

                    ' return the child object
                    Return Me.Children(index)
                Else
                    Throw New Msaa.ObjectIsElementException
                End If
            End Get
        End Property

        ' get the number of children the object has
        Public ReadOnly Property ChildCount() As Integer
            Get
                Try
                    If m_childId = 0 Then
                        Return m_msaa.accChildCount
                    Else
                        Return CType(m_msaa.accChild(m_childId), IAccessible).accChildCount
                    End If
                Catch
                    Return 0
                End Try
            End Get
        End Property

        ' get the cached child id
        Public ReadOnly Property ChildID() As Integer
            Get
                Return m_childId
            End Get
        End Property

        ' get the control's default action
        Public ReadOnly Property DefaultAction() As String
            Get
                Try
                    Return m_msaa.accDefaultAction(Me.ChildID)
                Catch
                    Return ""
                End Try
            End Get
        End Property

        ' get the control's description
        Public ReadOnly Property Description() As String
            Get
                Try
                    Return m_msaa.accDescription(Me.ChildID)
                Catch
                    Return ""
                End Try
            End Get
        End Property

        ' get the contorl's keyboard shortcut
        Public ReadOnly Property KeyboardShortcut() As String
            Get
                Try
                    Return m_msaa.accKeyboardShortcut(Me.ChildID)
                Catch
                    Return ""
                End Try
            End Get
        End Property

        ' get the control's name
        Public ReadOnly Property Name() As String
            Get
                Try
                    Return m_msaa.accName(m_childId)
                Catch
                    Return ""
                End Try
            End Get
        End Property

        ' get the control's parent
        Public ReadOnly Property Parent() As AccessibleObject
            Get
                If (m_childId = 0) Then
                    Return New AccessibleObject(AccessibleObject:=CType(m_msaa.accParent, IAccessible))
                Else
                    Return New AccessibleObject(AccessibleObject:=m_msaa)
                End If
            End Get
        End Property

        ' get the control's role
        Public Overloads ReadOnly Property Role() As Integer
            Get
                Try
                    Return CInt(m_msaa.accRole(m_childId))
                Catch
                    Return 0
                End Try
            End Get
        End Property

        ' get the control's role as a string
        Public ReadOnly Property RoleText() As String
            Get
                Try
                    Dim roleID As Integer = CInt(m_msaa.accRole(m_childId))
                    Dim roleString As New StringBuilder(MaxRole)
                    NativeMethods.GetRoleText(roleID, roleString, MaxRole)
                    Return roleString.ToString()
                Catch
                    Return ""
                End Try
            End Get
        End Property

        ' get the control's state
        Public ReadOnly Property State() As Integer
            Get
                If TypeOf m_msaa.accState(Me.ChildID) Is Integer Then
                    Return CInt(m_msaa.accState(Me.ChildID))
                Else
                    Return 0
                End If
            End Get
        End Property

        ' get the control's state as a string
        Public ReadOnly Property StateText() As String
            Get
                Try
                    Dim stateBit As Integer
                    Dim tmpStateText As String

                    Dim state As Integer = CInt(m_msaa.accState(Me.ChildID))
                    Dim stateString As New StringBuilder(MaxState)

                    ' get the state text for the normal state separately
                    If state = 0 Then
                        NativeMethods.GetStateText(stateBit, stateString, MaxState)
                    Else
                        For Each stateBit In [Enum].GetValues(GetType(MsaaStates))
                            If (state And stateBit) = stateBit Then
                                NativeMethods.GetStateText(stateBit, stateString, MaxState)
                                tmpStateText = tmpStateText & "," & stateString.ToString()
                            End If
                        Next stateBit
                    End If

                    Return tmpStateText.TrimStart(","c)
                Catch
                    Return ""
                End Try
            End Get
        End Property

        ' get the control's value
        Public ReadOnly Property Value() As String
            Get
                Try
                    Return m_msaa.accValue(Me.ChildID)
                Catch
                    Return ""
                End Try
            End Get
        End Property

#End Region

#Region "Public Methods"

        ' get the control's hwnd
        Public ReadOnly Property Hwnd() As IntPtr
            Get
                If Me.m_hwnd.ToInt32 = 0 Then
                    Dim handle As IntPtr

                    ' get a handle from the accessible object we have
                    NativeMethods.WindowFromAccessibleObject(m_msaa, handle)

                    ' create an accessible object
                    Dim msaa As New AccessibleObject(Me.IAccessible)

                    ' cache the hwnd for future use
                    m_hwnd = handle

                    Return handle
                Else
                    Return Me.m_hwnd
                End If
            End Get
        End Property

        ' get the pointer to the control's interface
        Public ReadOnly Property IAccessible() As IAccessible
            Get
                Return m_msaa
            End Get
        End Property

        ' get the control's x coordinate
        Public ReadOnly Property X() As Integer
            Get
                Try
                    Dim x0, y0, width, height As Integer
                    m_msaa.accLocation(x0, y0, width, height, m_childId)
                    Return x0
                Catch
                    Return 0
                End Try
            End Get
        End Property

        ' get the control's y coordinate
        Public ReadOnly Property Y() As Integer
            Get
                Try
                    Dim x0, y0, width, height As Integer
                    m_msaa.accLocation(x0, y0, width, height, m_childId)
                    Return y0
                Catch
                    Return 0
                End Try
            End Get
        End Property

        ' get the control's width
        Public ReadOnly Property Width() As Integer
            Get
                Try
                    Dim x0, y0, w, h As Integer
                    m_msaa.accLocation(x0, y0, w, h, m_childId)
                    Return w
                Catch
                    Return 0
                End Try
            End Get
        End Property

        ' get the control's height
        Public ReadOnly Property Height() As Integer
            Get
                Try
                    Dim x0, y0, w, h As Integer
                    m_msaa.accLocation(x0, y0, w, h, m_childId)
                    Return h
                Catch
                    Return 0
                End Try
            End Get
        End Property

        ' get the classname for the control
        Public ReadOnly Property ClassName() As String
            Get
                Dim windowClassString As New String("0"c, 256)
                Dim windowClassPtr As IntPtr = Marshal.StringToHGlobalAnsi(windowClassString)
                Dim count As Integer = NativeMethods.GetClassName(Me.Hwnd, windowClassPtr, 255)
                windowClassString = Marshal.PtrToStringAnsi(windowClassPtr, count)
                Marshal.FreeHGlobal(windowClassPtr)
                Return windowClassString
            End Get
        End Property

        ' get the control's caption
        Public ReadOnly Property Caption()
            Get
                Dim chararray() As Char

                Dim length As Integer = CInt(NativeMethods.GetWindowTextLength(m_hwnd) And &HFFFF&)
                ReDim chararray(length + 1)
                length = NativeMethods.GetWindowText(m_hwnd, chararray, length + 1)

                Return New String(chararray, 0, length)
            End Get
        End Property

        ' get the collection of msaa children for the control
        Public ReadOnly Property Children() As ActiveAccessibilityCollection
            Get

                Dim childrenReturned As Integer
                Dim theChildren() As Object
                Dim childIAcc As IAccessible
                Dim index As Integer

                Dim childCount As Integer = Me.ChildCount
                Dim result As New ActiveAccessibilityCollection

                If Me.ChildCount > 0 Then
                    ReDim theChildren(Me.ChildCount - 1)
                    Try
                        NativeMethods.AccessibleChildren(m_msaa, 0, childCount, theChildren, childrenReturned)
                    Catch
                    End Try

                    For index = 0 To childrenReturned - 1
                        If TypeOf theChildren(index) Is IAccessible Then
                            childIAcc = CType(theChildren(index), IAccessible)
                        Else
                            childIAcc = Nothing
                        End If

                        If Not childIAcc Is Nothing Then
                            ' the cast to IAccessible was successful, so just add it to the collection
                            result.Add(New AccessibleObject(childIAcc))
                        Else
                            ' wouldn't cast, so it's a child ID
                            result.Add(New AccessibleObject(m_msaa, CInt(theChildren(index))))
                        End If
                    Next
                End If

                Return result
            End Get
        End Property

        ' get the number of items in a list box
        Public ReadOnly Property ListboxCount() As Integer
            Get
                Dim result As IntPtr = NativeMethods.SendMessage(Me.Hwnd, NativeMethods.LB_GETCOUNT, IntPtr.Zero, IntPtr.Zero)
                If result.ToInt32() = NativeMethods.LB_ERR Then
                    Throw New ApiCallFailedException("Failed to get the count of ListBox items")
                End If

                Return result.ToInt32()
            End Get
        End Property

        ' get the text in the list box
        Public ReadOnly Property ListboxText(ByVal listItemIndex As Integer) As String
            Get
                Dim lParam As New StringBuilder(NativeMethods.NumBytes)
                Dim length As Integer = NativeMethods.SendMessageByStringBuilder(Me.Hwnd, NativeMethods.LB_GETTEXT, New IntPtr(listItemIndex), lParam).ToInt32()
                If length = NativeMethods.LB_ERR Then
                    Throw New ApiCallFailedException("Failed to get the text in the list box")
                End If

                Return lParam.ToString()
            End Get
        End Property

        ' get the text in the edit box
        Public ReadOnly Property TextboxText() As String
            Get
                Dim lParam As New StringBuilder(NativeMethods.NumBytes)
                Dim result As IntPtr = NativeMethods.SendMessageByStringBuilder(Me.Hwnd, NativeMethods.WM_GETTEXT, New IntPtr(NativeMethods.NumBytes), lParam)
                If result.ToInt32 > 0 Then
                    TextboxText = lParam.ToString()
                Else
                    Throw New ApiCallFailedException("Failed to get the text in the edit box")
                End If
            End Get
        End Property

        ' get the check box's state
        Public ReadOnly Property CheckBoxState() As CheckBoxState
            Get
                ' todo: Are there any messages we can send to the checkbox to determine whether it is really checked or not?
            End Get
        End Property

        ' get the number of items in the combo box
        Public ReadOnly Property ComboBoxCount() As Integer
            Get
                Dim result As IntPtr = NativeMethods.SendMessage(Me.Hwnd, NativeMethods.CB_GETCOUNT, IntPtr.Zero, IntPtr.Zero)
                If result.ToInt32() = NativeMethods.CB_ERR Then
                    Throw New ApiCallFailedException("Failed to get the count of ComboBox items")
                Else
                    Return result.ToInt32()
                End If
            End Get
        End Property

        ' get the text in the combo box
        Public Overloads ReadOnly Property ComboBoxText() As String
            Get
                Return ComboBoxText(-1)
            End Get
        End Property

        ' get the text of the specified combo box list item
        Public Overloads ReadOnly Property ComboBoxText(ByVal index As Integer) As String
            Get
                Dim result As IntPtr
                Dim lParam As New StringBuilder(NativeMethods.NumBytes \ 2)

                If index = -1 Then
                    index = Me.ComboBoxSelectedIndex
                End If

                If index < -1 Or index >= ComboBoxCount Then
                    Throw New System.ArgumentException("Requested ComboBox item index is invalid")
                End If

                If index = -1 Then
                    Throw New ApiCallFailedException("Failed to get the text from the combo box")
                Else
                    result = NativeMethods.SendMessageByStringBuilder(Me.Hwnd, NativeMethods.CB_GETLBTEXT, New IntPtr(index), lParam)
                    If result.ToInt64() > 0 Then
                        Return lParam.ToString
                    Else
                        Throw New ApiCallFailedException("Failed to get the text from the combo box")
                    End If
                End If
            End Get
        End Property

        ' get the number of items in the list view
        Public ReadOnly Property ListViewCount() As Integer
            Get
                Return NativeMethods.SendMessage(Hwnd, NativeMethods.LVM_GETITEMCOUNT, IntPtr.Zero, IntPtr.Zero).ToInt32()
            End Get
        End Property

        ' get the hwnd of the list view header
        Public Function ListViewHeaderHandle() As IntPtr
            Return NativeMethods.SendMessage(Hwnd, NativeMethods.LVM_GETHEADER, IntPtr.Zero, IntPtr.Zero)
        End Function

        ' determine whether the list view has headers
        Public Function ListViewHasHeader() As Boolean
            If ListViewHeaderHandle.ToInt64() = 0 Then
                Return False
            Else
                Return True
            End If
        End Function

        ' get the text of the list view
        Public Overloads ReadOnly Property ListViewText(ByVal listItemIndex As Integer) As String
            Get
                Return ListViewText(listItemIndex, 0)
            End Get
        End Property

        ' get the text of the specified list view item or column index
        ' this code segment was written by "dan the man" who is promising a blog entry about how this works
        Public Overloads ReadOnly Property ListViewText(ByVal listItemIndex As Integer, ByVal listColumnIndex As Integer) As String
            Get
                '//creating and reading from a shared memory region is done differently in Win9x then in newer OSs
                Dim processHandle As IntPtr
                Dim fileHandle As IntPtr
                Dim fileHandle2 As IntPtr 'handle to the target process
                Dim LVITEM As NativeMethods.LVITEM
                Dim bufferMem As IntPtr 'base address of the allocated region for the buffer
                Dim lvItemMem As IntPtr 'base address of the allocated region for the LVITEM structure
                Dim size As Integer 'the amount of memory to be allocated
                Dim written As IntPtr 'number of bytes written to memory
                Dim returnVal As Integer
                Dim returnHandle As IntPtr
                Dim procID As Integer

                Dim bytearray(1023) As Byte
                size = 1024

                Try
                    NativeMethods.GetWindowThreadProcessId(Me.Hwnd, procID)
                    processHandle = NativeMethods.OpenProcess(NativeMethods.PROCESS_VM_OPERATION Or NativeMethods.PROCESS_VM_READ Or NativeMethods.PROCESS_VM_WRITE, CInt(False), procID)
                    If processHandle.ToInt64() = 0 Then
                        Err.Raise(Err.LastDllError, "xprocGetLVNodeCaption", "OpenProcess API Failed")
                    End If

                    bufferMem = NativeMethods.VirtualAllocEx(processHandle, IntPtr.Zero, New IntPtr(size), NativeMethods.MEM_RESERVE Or NativeMethods.MEM_COMMIT, NativeMethods.PAGE_READWRITE)
                    If bufferMem.ToInt64() = 0 Then
                        Err.Raise(Err.LastDllError, "xprocGetLVNodeCaption", "VirtualAllocEx API Failed")
                    End If

                    '//declare a treeview node structure and populate its members in preparation for retrieving the node's caption
                    LVITEM.iItem = listItemIndex
                    LVITEM.iSubItem = listColumnIndex
                    LVITEM.mask = NativeMethods.LVIF_TEXT
                    LVITEM.pszText = bufferMem 'pointer to the buffer in the shared memory
                    LVITEM.cchTextMax = 1024

                    '//allocate space in the target process for the LVITEM as shared memory
                    size = Marshal.SizeOf(LVITEM)

                    lvItemMem = NativeMethods.VirtualAllocEx(processHandle, IntPtr.Zero, New IntPtr(size), NativeMethods.MEM_RESERVE Or NativeMethods.MEM_COMMIT, NativeMethods.PAGE_READWRITE)
                    If lvItemMem.ToInt64() = 0 Then
                        Err.Raise(Err.LastDllError, "xprocGetLVNodeCaption", "VirtualAllocEx API Failed")
                    End If

                    '//write the LVITEM to the allocated shared memory
                    returnVal = NativeMethods.WriteProcessMemoryLV(processHandle, lvItemMem, LVITEM, New IntPtr(size), written)
                    If returnVal = 0 Then
                        Err.Raise(Err.LastDllError, "xprocGetLVNodeCaption", "WriteProcessMemory API Failed")
                    End If

                    '//send message to the listview control's hWnd for getting the specified item's info (via LVM_GETITEM)
                    returnHandle = NativeMethods.SendMessage(Hwnd, NativeMethods.LVM_GETITEMTEXT, New IntPtr(listItemIndex), lvItemMem) 'note that we pass in the pointer to the shared memory rather then a ref to the TVITEM itself

                    '//now read the LVITEM's info from the shared memory location
                    returnVal = NativeMethods.ReadProcessMemoryLV(processHandle, lvItemMem, LVITEM, New IntPtr(size), written)
                    If returnVal = 0 Then
                        Err.Raise(Err.LastDllError, "xprocGetLVNodeCaption", "ReadProcessMemory API Failed")
                    End If

                    '//read the LVITEM's caption info from the specific shared memory for the buffer (note that LVITEM.pszText points to this memory block)
                    size = 1024 'Len(bytearray)
                    returnVal = NativeMethods.ReadProcessMemory(processHandle, bufferMem, bytearray(0), New IntPtr(size), written)
                    If returnVal = 0 Then
                        Err.Raise(Err.LastDllError, "xprocGetLVNodeCaption", "ReadProcessMemory API Failed")
                    End If
                Catch e As Exception
                    Throw e
                Finally
                    '//free the memory that was allocated
                    returnVal = NativeMethods.VirtualFreeEx(processHandle, lvItemMem, New IntPtr(0), NativeMethods.MEM_RELEASE)
                    If returnVal = 0 Then
                        Err.Raise(Err.LastDllError, "xprocGetLVNodeCaption", "VirtualFreeEx API Failed" & Err.Description)
                    End If
                    returnVal = NativeMethods.VirtualFreeEx(processHandle, bufferMem, New IntPtr(0), NativeMethods.MEM_RELEASE)
                    If returnVal = 0 Then
                        Err.Raise(Err.LastDllError, "xprocGetLVNodeCaption", "VirtualFreeEx API Failed")
                    End If
                    NativeMethods.CloseHandle(processHandle)
                End Try

                Return Encoding.Unicode.GetString(bytearray).TrimEnd(Chr(0))
            End Get
        End Property

        ' get the number of sub items in a list view
        Public ReadOnly Property ListViewSubItemCount() As Integer
            Get
                ' the list view and list view items have the same hwnd.  The column headers have a different hwnd
                Dim columnHwnd As IntPtr = ListViewHeaderHandle()
                Dim returnValue As IntPtr = NativeMethods.SendMessage(columnHwnd, NativeMethods.HDM_GETITEMCOUNT, IntPtr.Zero, IntPtr.Zero)

                If returnValue.ToInt32() = -1 Then
                    Throw New ApiCallFailedException("Failed to get the number of list view sub items")
                Else
                    ListViewSubItemCount = returnValue.ToInt32()
                End If
            End Get
        End Property

        ' get the text of the specified list view header
        ' this code segment was written by "dan the man" who is promising a blog entry about how this works
        Public ReadOnly Property ListViewHeaderText(ByVal index As Integer) As String
            Get
                Dim memSize As Object

                '//get the pid of the process that contains the Header
                Dim ProcId As Integer 'pid of the process that contains the Header control

                '//define the buffer that will eventually contain the desired node's caption
                '//this should be 1023 because array indecies start with 0
                Dim bytearray(1023) As Byte

                '//allocate space in the target process for the buffer as shared memory
                Dim HDITEM As NativeMethods.HDITEM
                Dim bufferMem As IntPtr 'base address of the allocated region for the buffer
                Dim HDITEMMem As IntPtr 'base address of the allocated region for the HDITEM structure
                Dim size As Integer = 1024 ' the amount of memory to be allocated
                Dim written As IntPtr 'number of bytes written to memory
                Dim returnVal As Integer
                Dim returnHandle As IntPtr
                '//creating and reading from a shared memory region is done diferently in Win9x then in newer OSs
                Dim processHandle As IntPtr
                Dim fileHandle As IntPtr
                Dim fileHandle2 As IntPtr 'handle to the target process
                Dim hwnd As IntPtr = ListViewHeaderHandle()

                Try
                    NativeMethods.GetWindowThreadProcessId(hwnd, ProcId)
                    processHandle = NativeMethods.OpenProcess(NativeMethods.PROCESS_VM_OPERATION Or NativeMethods.PROCESS_VM_READ Or NativeMethods.PROCESS_VM_WRITE, CInt(False), ProcId)
                    If processHandle.ToInt64() = 0 Then
                        Err.Raise(Err.LastDllError, "XProcGetHeaderText", "OpenProcess API Failed")
                    End If

                    bufferMem = NativeMethods.VirtualAllocEx(processHandle, IntPtr.Zero, New IntPtr(size), NativeMethods.MEM_RESERVE Or NativeMethods.MEM_COMMIT, NativeMethods.PAGE_READWRITE)
                    If bufferMem.ToInt64() = 0 Then
                        Err.Raise(Err.LastDllError, "XProcGetHeaderText", "VirtualAllocEx API Failed")
                    End If

                    '//declare a treeview node structure and populate its members in preparation for retrieving the node's caption
                    HDITEM.mask = NativeMethods.HDI_TEXT
                    HDITEM.pszText = bufferMem 'pointer to the buffer in the shared memory
                    HDITEM.cchTextMax = 1024

                    '//allocate space in the target process for the HDITEM as shared memory
                    size = Marshal.SizeOf(HDITEM)

                    HDITEMMem = NativeMethods.VirtualAllocEx(processHandle, IntPtr.Zero, New IntPtr(size), NativeMethods.MEM_RESERVE Or NativeMethods.MEM_COMMIT, NativeMethods.PAGE_READWRITE)
                    If HDITEMMem.ToInt64() = 0 Then
                        Err.Raise(Err.LastDllError, "XProcGetHeaderText", "VirtualAllocEx API Failed")
                    End If

                    '//write the HDITEM to the allocated shared memory
                    returnVal = NativeMethods.WriteProcessMemoryHD(processHandle, HDITEMMem, HDITEM, New IntPtr(size), written)
                    If returnVal = 0 Then
                        Err.Raise(Err.LastDllError, "XProcGetHeaderText", "WriteProcessMemory API Failed")
                    End If

                    '//send message to the Header control's hWnd for getting the specified item's info (via LVM_GETITEM)
                    returnHandle = NativeMethods.SendMessage(hwnd, NativeMethods.HDM_GETITEM, New IntPtr(index), HDITEMMem) 'note that we pass in the pointer to the shared memory rather then a ref to the TVITEM itself

                    '//now read the HDITEM's info from the shared memory location
                    returnVal = NativeMethods.ReadProcessMemoryHD(processHandle, HDITEMMem, HDITEM, New IntPtr(size), written)
                    If returnVal = 0 Then
                        Err.Raise(Err.LastDllError, "XProcGetHeaderText", "ReadProcessMemory API Failed")
                    End If

                    '//read the HDITEM's caption info from the specific shared memory for the buffer (note that HDITEM.pszText points to this memory block)
                    size = 1024 'Len(bytearray)
                    returnVal = NativeMethods.ReadProcessMemory(processHandle, bufferMem, bytearray(0), New IntPtr(size), written)
                    If returnVal = 0 Then
                        Err.Raise(Err.LastDllError, "XProcGetHeaderText", "ReadProcessMemory API Failed")
                    End If
                Catch e As Exception
                    Throw e
                Finally
                    '//free the memory that was allocated
                    returnVal = NativeMethods.VirtualFreeEx(processHandle, HDITEMMem, New IntPtr(0), NativeMethods.MEM_RELEASE)
                    If returnVal = 0 Then
                        Err.Raise(Err.LastDllError, "XProcGetHeaderText", "VirtualFreeEx API Failed")
                    End If
                    returnVal = NativeMethods.VirtualFreeEx(processHandle, bufferMem, New IntPtr(0), NativeMethods.MEM_RELEASE)
                    If returnVal = 0 Then
                        Err.Raise(Err.LastDllError, "XProcGetHeaderText", "VirtualFreeEx API Failed")
                    End If
                    NativeMethods.CloseHandle(processHandle)
                End Try

                Return Encoding.Unicode.GetString(bytearray).TrimEnd(Chr(0))
            End Get
        End Property

        ' get the number of status bar panels
        Public ReadOnly Property StatusBarPanelCount() As Integer
            Get
                Return NativeMethods.SendMessage(Me.Hwnd, NativeMethods.SB_GETPARTS, IntPtr.Zero, IntPtr.Zero).ToInt32()
            End Get
        End Property

        ' get the text from the specified status bar panels
        ' this code segment was written by "dan the man" who is promising a blog entry about how this works
        Public ReadOnly Property StatusBarPanelText(ByVal index As Integer) As String
            Get
                Dim result, hiWord, typeLengthWord As Integer
                Dim lParam As New String(Chr(0), NativeMethods.NumBytes \ 2)

                Dim procID As Integer
                Dim tid As Integer     'owner window's thread id            
                tid = NativeMethods.GetWindowThreadProcessId(Me.Hwnd, procID)

                typeLengthWord = NativeMethods.SendMessage(Me.Hwnd, NativeMethods.SB_GETTEXTLENGTH, New IntPtr(index), IntPtr.Zero).ToInt32()
                hiWord = GetHiWord(typeLengthWord)
                If (hiWord And NativeMethods.SBT_OWNERDRAW) = NativeMethods.SBT_OWNERDRAW Then
                    Throw New MsaaVerify.StatusBarPanelTextException("The Status Bar you are trying to access is owner drawn so we can't get the text")
                End If

                Dim size As Integer = NativeMethods.NumBytes
                Dim byteArray(size) As Byte
                Dim bytesWritten As IntPtr
                Dim hProcess As IntPtr
                Dim stringMem As IntPtr

                Try
                    hProcess = NativeMethods.OpenProcess(NativeMethods.PROCESS_VM_OPERATION Or NativeMethods.PROCESS_VM_READ Or NativeMethods.PROCESS_VM_WRITE, 0, procID)
                    If hProcess.ToInt64() = 0 Then
                        Throw New ApiCallFailedException("OpenProcess API Failed: " & Err.LastDllError)
                    End If

                    stringMem = NativeMethods.VirtualAllocEx(hProcess, IntPtr.Zero, New IntPtr(size), NativeMethods.MEM_RESERVE Or NativeMethods.MEM_COMMIT, NativeMethods.PAGE_READWRITE)
                    If stringMem.ToInt64() = 0 Then
                        Throw New ApiCallFailedException("VirtualAllocEx API Failed: " & Err.LastDllError)
                    End If

                    ' write String to the allocated shared memory
                    result = NativeMethods.WriteProcessMemory(hProcess, stringMem, byteArray(0), New IntPtr(size), bytesWritten)
                    If result = 0 Then
                        Throw New ApiCallFailedException("WriteProcessMemory API Failed: " & Err.LastDllError)
                    End If

                    ' send message to the hWnd for getting the specified item's info
                    'note that we pass in the pointer to the shared memory rather then a ref to the String itself
                    Dim retValue As IntPtr = NativeMethods.SendMessage(Me.Hwnd, NativeMethods.SB_GETTEXT, New IntPtr(index), stringMem)

                    ' now read the String's info from the shared memory location - lparam's value 
                    '(which was passed ByRef, should now be changed accordingly)
                    result = NativeMethods.ReadProcessMemory(hProcess, stringMem, byteArray(0), New IntPtr(size), bytesWritten)
                    If result = 0 Then
                        Throw New ApiCallFailedException("ReadProcessMemory API Failed: " & Err.LastDllError)
                    End If
                Catch e As Exception
                    Throw e
                Finally
                    ' free the memory that was allocated                    
                    result = NativeMethods.VirtualFreeEx(hProcess, stringMem, New IntPtr(0), NativeMethods.MEM_RELEASE)
                    If result = 0 Then
                        Throw New ApiCallFailedException("VirtualFreeEx API Failed: " & Err.LastDllError)
                    End If
                    NativeMethods.CloseHandle(hProcess)
                End Try

                lParam = Encoding.Unicode.GetString(byteArray).TrimEnd(Chr(0))
                If result > 0 Then
                    Return lParam.ToString()
                Else
                    Return ""
                End If
            End Get
        End Property

#End Region

#Region "Private Methods"

        ' cache the control's hwnd
        Private Function SetHwnd(ByVal windowHandle As IntPtr)
            m_hwnd = windowHandle
        End Function

        ' record errors for certain controls together
        Private Shared Sub AddMsaaError(ByRef errorStr As String, ByVal errorToAdd As String)
            If errorStr = "" Then
                errorStr = errorToAdd
            Else
                errorStr += ";" + errorToAdd
            End If
        End Sub

        ' get the combo box's selected index
        Private ReadOnly Property ComboBoxSelectedIndex() As Integer
            Get
                Return NativeMethods.SendMessage(Me.Hwnd, NativeMethods.CB_GETCURSEL, IntPtr.Zero, IntPtr.Zero).ToInt32()
            End Get
        End Property

        Private Shared Function GetHiWord(ByVal value As Integer) As Integer
            Return (value - GetLoWord(value)) \ &H10000
        End Function

        Private Shared Function GetLoWord(ByVal value As Integer) As Integer
            Return value And &H7FFF
        End Function

        ' generate the expected description for a list view
        Private Sub BuildListViewItemDescription(ByVal descriptionToAdd As String, ByRef expectedDescription As String)
            If expectedDescription = "" Then
                expectedDescription = descriptionToAdd
            Else
                expectedDescription += ", " + descriptionToAdd
            End If
        End Sub

        ' determine whether a window is valid
        Public Function IsWindowValid() As Boolean
            Return NativeMethods.IsWindow(m_hwnd) <> 0
        End Function

#End Region

#Region "MsaaVerify Methods"

        Public Function VerifyChildCount(ByRef resultsLog As String, ByVal typeofList As ListType) As Boolean
            ' Verify input to these functions
            resultsLog = ""
            If typeofList < 0 OrElse typeofList > 2 Then
                Throw New Msaa.ChildCountException("Invalid argument ListType passed in.  Cannot continue with verifications")
            End If

            Dim childCount As Integer
            Dim childID As Integer = Me.ChildID
            Dim ex As System.Runtime.InteropServices.COMException

            Try
                Dim aaObject As Accessibility.IAccessible = Me.IAccessible
                If childID = Me.ChildId_Self Then
                    childCount = aaObject.accChildCount
                Else
                    Dim aaChildObject As Object = aaObject.accChild(childID)
                    ' if the current object is a simple element, that is, an object that is a child of an AA object,
                    ' but does not have children of its own, calling IAccessible::get_accChild() will return S_FALSE with a null pointer
                    ' S_OK and S_FALSE HRESULTS do not throw exceptions, so if aaChildObject is null, we know S_FALSE was returned,
                    ' and the object is a simple element
                    If aaChildObject Is Nothing Then
                        childCount = 0
                    Else
                        childCount = CType(aaChildObject, Accessibility.IAccessible).accChildCount
                    End If
                End If
            Catch ex
                ' catch all exceptions here.  Let MsaaVerify handle it, since msaa verifications cannot be performed
            End Try

            Select Case Me.Role

                Case MsaaRoles.StaticText, MsaaRoles.PushButton, MsaaRoles.CheckButton, MsaaRoles.RadioButton, MsaaRoles.Text, MsaaRoles.ProgressBar
                    If Not ex Is Nothing Then
                        ' These control types do not support child count, so verify DISP_E_MEMBERNOTFOUND is returned
                        ' if any other COM result is returned, it is a failure. 
                        If ex.ErrorCode <> NativeMethods.DISP_E_MEMBERNOTFOUND Then
                            Throw New Msaa.ChildCountException("Control doesn't support children.  Must return DISP_E_MEMBERNOTFOUND.  The following COM exception was caught: " & ex.Message, ex)
                        End If
                    End If

                    resultsLog = Me.ResultsLogFormat(0, childCount, "Control does not support children")
                    If childCount = 0 Then
                        Return True ' passed 
                    Else
                        Return False ' failed
                    End If

                Case MsaaRoles.StatusBar
                    If Not ex Is Nothing Then
                        Throw New Msaa.ChildCountException("ChildCount must be supported and match the number of status bar panes.  Return DISP_E_MEMBERNOTFOUND.  Progress bar threw the following COM exception: " & ex.Message, ex)
                    End If

                    ' The ChildCount property is the number of panes in the status bar
                    resultsLog = Me.ResultsLogFormat(StatusBarPanelCount, childCount, "ChildCount is the number of status bar panes")
                    If childCount = StatusBarPanelCount Then
                        Return True ' passed 
                    Else
                        Return False ' failed
                    End If

                Case MsaaRoles.List
                    ' must determine which list we have
                    Select Case typeofList

                        Case ListType.ListBox
                            If Not ex Is Nothing Then
                                ' list box must support childcount, even if the listbox has no items.
                                Throw New Msaa.ChildCountException("Childcount must be supported and match the number of items in the listbox.  Listbox threw the following COM exception: " & ex.Message, ex)
                            End If

                            Dim expectedChildCount As Integer = ListboxCount
                            resultsLog = Me.ResultsLogFormat(expectedChildCount, childCount, "ChildCount is the number of items in the listbox")
                            If childCount = expectedChildCount Then
                                Return True ' passed
                            Else
                                Return False ' failed
                            End If

                        Case ListType.ListView
                            If Not ex Is Nothing Then
                                ' list view must support childcount, even if the listview has no items. 
                                Throw New Msaa.ChildCountException("ChildCount must be supported and match the number of items in the listview.  Threw the following COM exception: " & ex.Message, ex)
                            End If

                            Dim expectedChildCount As Integer = ListViewCount

                            If ListViewHasHeader() Then
                                ' if there are column headers, add one to the expected child count 
                                expectedChildCount += 1
                                resultsLog = Me.ResultsLogFormat(expectedChildCount, childCount, "ChildCount is the number of items in the ListView plus one for the column headers")
                                If childCount = expectedChildCount Then
                                    Return True ' passed
                                Else
                                    Return False ' failed
                                End If
                            Else
                                ' if there are no column headers, the expected child count matches the number of children
                                resultsLog = Me.ResultsLogFormat(expectedChildCount, childCount, "ChildCount is the number of items in the listview")
                                If childCount = expectedChildCount Then
                                    Return True ' passed
                                Else
                                    Return False ' failed
                                End If
                            End If

                        Case ListType.Neither
                            Throw New Msaa.ChildCountException("Cannot verify object with Role of List because it is neither a list box nor a list view")

                        Case Else
                            Throw New Msaa.ChildCountException("Cannot verify object with Role of List because it is neither a list box nor a list view")
                    End Select

                Case MsaaRoles.ListItem
                    ' must determine which list we have
                    Select Case typeofList

                        Case ListType.ListBox, ListType.ListView
                            If Not ex Is Nothing Then
                                If ex.ErrorCode <> NativeMethods.DISP_E_MEMBERNOTFOUND Then
                                    Throw New Msaa.ChildCountException("Items in a list do not have children.  Must return DISP_E_MEMBERNOTFOUND.  The following COM exception was caught: " & ex.Message, ex)
                                End If
                            End If

                            resultsLog = Me.ResultsLogFormat(0, childCount, "Items in a list box do not have children")
                            If childCount = 0 Then
                                Return True ' passed
                            Else
                                Return False ' failed
                            End If

                        Case ListType.Neither
                            Throw New Msaa.ChildCountException("Cannot verify object with Role of List because it is neither a list box nor a list view")

                        Case Else
                            Throw New Msaa.ChildCountException("Cannot verify object with Role of List because it is neither a list box nor a list view")
                    End Select

                Case MsaaRoles.ComboBox

                    If Not ex Is Nothing Then
                        ' ComboBox must support child count. Testcase must catch ChildCountException type 
                        Throw New Msaa.ChildCountException("Returned the following COM error code: " & ex.Message, ex)
                    End If

                    ' combo box must have a childCount of 3
                    resultsLog = Me.ResultsLogFormat(3, childCount, "ComboBox must have 3 children: EditBox, List, and PushButton")
                    If childCount = 3 Then
                        Return True
                    Else
                        Return False
                    End If

                Case Else
                    resultsLog = "unable to perform verifications on control of role type " & Me.RoleText
                    Return False
            End Select
        End Function

        Public Function VerifyDescription(ByRef resultsLog As String, ByVal expectedDescription As String, ByVal typeofList As ListType) As Boolean
            ' Verify input to these functions
            resultsLog = ""
            If typeofList < 0 OrElse typeofList > 2 Then
                Throw New Msaa.ChildCountException("Invalid argument ListType passed in.  Cannot continue with verifications")
            End If

            Dim description As String = ""
            Dim ex As System.Runtime.InteropServices.COMException

            Try
                Dim aaObject As Accessibility.IAccessible = Me.IAccessible
                description = aaObject.accDescription(Me.ChildID)
            Catch ex
                ' catch all exceptions here.  Let MsaaVerify handle it, since msaa verifications cannot be performed
            End Try

            Select Case Me.Role

                Case MsaaRoles.StaticText, MsaaRoles.PushButton, MsaaRoles.CheckButton, MsaaRoles.ComboBox, MsaaRoles.RadioButton, MsaaRoles.ProgressBar, MsaaRoles.StatusBar, MsaaRoles.Text, MsaaRoles.List
                    If Not ex Is Nothing Then
                        ' Description is not required, so it is okay to return DISP_E_MEMBERNOTFOUND
                        ' if any other COM result is returned, it is a failure. Testcase must catch DescriptionException type
                        If ex.ErrorCode <> NativeMethods.DISP_E_MEMBERNOTFOUND Then
                            Throw New Msaa.DescriptionException("If the control does not have a description, return DISP_E_MEMBERNOTFOUND. The following COM exception was caught:" & ex.Message, ex)
                        End If
                    End If

                    ' check whether user supplied a description
                    If expectedDescription = "" Then
                        ' user did not specify a description, so check whether the control has an accessible description
                        If description = "" Then
                            resultsLog = Me.ResultsLogFormat(expectedDescription, description, "A description is not required for this control")
                            Return True ' passed
                        Else
                            resultsLog = Me.ResultsLogFormat(expectedDescription, description, "A description was found, but the user didn't specify a description to verify. A description is not required for this control")
                            Return False ' failed
                        End If
                    Else
                        ' check whether the description matches the one specified by the user
                        resultsLog = Me.ResultsLogFormat(expectedDescription, description, "The description must match the user-specified description.")
                        If expectedDescription = description Then
                            Return True ' passed
                        Else
                            Return False 'failed
                        End If
                    End If

                Case MsaaRoles.ListItem
                    ' must determine which list item type we have
                    Select Case typeofList

                        Case ListType.ListBox
                            ' Description is not required, so it is okay to return DISP_E_MEMBERNOTFOUND
                            ' if any other COM result is returned, it is a failure. 
                            If Not ex Is Nothing Then
                                If ex.ErrorCode <> NativeMethods.DISP_E_MEMBERNOTFOUND Then
                                    Throw New Msaa.DescriptionException("If the control does not have a description, return DISP_E_MEMBERNOTFOUND. The following COM exception was caught:" & ex.Message, ex)
                                End If
                            End If

                            ' check whether user supplied a description
                            If expectedDescription = "" Then
                                ' user did not specify a description, so check whether the control has an accessible description
                                If description = "" Then
                                    resultsLog = Me.ResultsLogFormat(expectedDescription, description, "A description is not required for this control")
                                    Return True ' passed
                                Else
                                    resultsLog = Me.ResultsLogFormat(expectedDescription, description, "A description was found, but the user didn't specify a description to verify. A description is not required for this control")
                                    Return False ' failed
                                End If
                            Else
                                ' check whether the description matches the one specified by the user
                                resultsLog = Me.ResultsLogFormat(expectedDescription, description, "The description must match the user-specified description.")
                                If expectedDescription = description Then
                                    Return True ' passed
                                Else
                                    Return False 'failed
                                End If
                            End If
                        Case ListType.ListView
                            ' if the list view contains headers, the additional column text is represented via description
                            If ListViewHasHeader() Then
                                If Not ex Is Nothing Then
                                    Throw New Msaa.ChildCountException("Description must be supported because it has column headers.  The following COM exception was caught: " & ex.Message, ex)
                                End If

                                ' the description must match the sub item text, so ignore anything specified in expectedDescription
                                ' because it could result in a false positive
                                expectedDescription = ""
                                Try
                                    ' start at 1 because the first column isn't included in the description
                                    For counter As Integer = 1 To ListViewSubItemCount - 1
                                        ' retrieve the list view text for the current AA child id - 1 because ChildIds are 1-based.
                                        Dim listItemSubItemText As String = ListViewText(Me.ChildID - 1, counter)
                                        ' if the text is null, the text won't appear in the description, so don't add it
                                        If listItemSubItemText <> "" Then
                                            BuildListViewItemDescription(ListViewHeaderText(counter) & ": " & listItemSubItemText, expectedDescription)
                                        End If
                                    Next
                                Catch e As Exception
                                    expectedDescription = ""
                                End Try

                                resultsLog = Me.ResultsLogFormat(expectedDescription, description, "The description contains information in the column headers and listview item subtext.")
                                If description = expectedDescription Then
                                    Return True ' passed
                                Else
                                    Return False ' failed
                                End If
                            Else
                                ' Description is not required, so it is okay to return DISP_E_MEMBERNOTFOUND
                                ' if any other COM result is returned, it is a failure. 
                                If Not ex Is Nothing Then
                                    If ex.ErrorCode <> NativeMethods.DISP_E_MEMBERNOTFOUND Then
                                        Throw New Msaa.DescriptionException("If method is not supported, return DISP_E_MEMBERNOTFOUND. Threw the following COM exception " & ex.Message, ex)
                                    End If
                                End If

                                ' check whether user supplied a description
                                If expectedDescription = "" Then
                                    ' user did not specify a description, so check whether the control has an accessible description
                                    If description = "" Then
                                        resultsLog = Me.ResultsLogFormat(expectedDescription, description, "A description is not required for this control")
                                        Return True ' passed
                                    Else
                                        resultsLog = Me.ResultsLogFormat(expectedDescription, description, "A description was found, but the user didn't specify a description to verify. A description is not required for this control")
                                        Return False ' failed
                                    End If
                                Else
                                    ' check whether the description matches the one specified by the user
                                    resultsLog = Me.ResultsLogFormat(expectedDescription, description, "The description must match the user-specified description.")
                                    If expectedDescription = description Then
                                        Return True ' passed
                                    Else
                                        Return False 'failed
                                    End If
                                End If
                            End If

                        Case ListType.Neither
                            Throw New Msaa.ChildCountException("Cannot verify object with Role=List because it is neither a list box nor a list view")

                        Case Else
                            Throw New Msaa.ChildCountException("Cannot verify object with Role=List because it is neither a list box nor a list view")
                    End Select

                Case Else
                    resultsLog = "unable to perform verifications on control of role type " & Me.RoleText
                    Return False ' failed
            End Select

            Return resultsLog = ""
        End Function

        Public Function VerifyDefaultAction(ByRef resultsLog As String, ByVal typeofList As ListType) As Boolean
            ' Verify input to these functions
            resultsLog = ""
            If typeofList < 0 OrElse typeofList > 2 Then
                Throw New Msaa.ChildCountException("Invalid argument ListType passed in.  Cannot continue with verifications")
            End If

            Dim defaultAction As String = ""
            Dim ex As System.Runtime.InteropServices.COMException

            Try
                Dim aaObject As Accessibility.IAccessible = Me.IAccessible
                defaultAction = aaObject.accDefaultAction(Me.ChildID)
            Catch ex
                ' catch all exceptions here.  Let MsaaVerify handle it, since msaa verifications cannot be performed
            End Try

            Select Case Me.Role

                Case MsaaRoles.StaticText, MsaaRoles.StatusBar
                    If Not ex Is Nothing Then
                        ' does not have a default action, so it is okay to return DISP_E_MEMBERNOTFOUND
                        ' if any other COM result is returned, it is a failure. 
                        If ex.ErrorCode <> NativeMethods.DISP_E_MEMBERNOTFOUND Then
                            Throw New Msaa.DefaultActionException("Does not support default action. Return DISP_E_MEMBERNOTFOUND. Threw the following COM exception " & ex.Message, ex)
                        End If
                    End If

                    resultsLog = Me.ResultsLogFormat("", defaultAction, "This control must not have a default action, because it doesn't perform an action.")
                    If defaultAction = "" Then
                        Return True ' passed
                    Else
                        Return False
                    End If

                Case MsaaRoles.PushButton
                    ' push button must support default action 
                    If Not ex Is Nothing Then
                        Throw New Msaa.DefaultActionException("Must support DefaultAction.  Threw COM exception: " & ex.Message, ex)
                    End If

                    ' check whether this push button belongs to a combo box or is a stand-alone push button
                    ' check parent and grandparent, in case the button has an invisble window wrapper object
                    ' most of the time, a push button parent is a combo box
                    Dim expectedDefaultAction As String
                    If Me.Parent.Role = MsaaRoles.ComboBox OrElse Me.Parent.Parent.Role = MsaaRoles.ComboBox Then
                        resultsLog = Me.ResultsLogFormat("Open", defaultAction, "The control must have a DefaultAction of Open.")
                        expectedDefaultAction = "Open"
                    Else
                        resultsLog = Me.ResultsLogFormat("Press", defaultAction, "The control must have a DefaultAction of Press.")
                        expectedDefaultAction = "Press"
                    End If

                    If defaultAction = expectedDefaultAction Then
                        Return True ' passed
                    Else
                        Return False ' failed
                    End If


                Case MsaaRoles.CheckButton
                    ' Check box must support default action. 
                    If Not ex Is Nothing Then
                        Throw New Msaa.DefaultActionException("Must support DefaultAction.  Threw COM exception: " & ex.Message, ex)
                    End If

                    ' first determine what state the checkbox is in
                    Select Case CheckBoxState
                        Case CheckBoxState.Checked
                            resultsLog = Me.ResultsLogFormat("Uncheck", defaultAction, "A checkbox in an checked state must have a defaultAction of Uncheck.")
                            If defaultAction = "Uncheck" Then
                                Return True ' passed
                            Else
                                Return False ' failed
                            End If

                        Case CheckBoxState.UnChecked
                            resultsLog = Me.ResultsLogFormat("Uncheck", defaultAction, "A checkbox in an unchecked state must have a defaultAction of Check.")
                            If defaultAction = "Check" Then
                                Return True ' passed
                            Else
                                Return False ' failed
                            End If
                        Case CheckBoxState.InDeterminate
                            resultsLog = Me.ResultsLogFormat("Toggle", defaultAction, "A checkbox in an indeterminate state must have a defaultAction of Toggle.")
                            If defaultAction <> "Toggle" Then
                                Return True ' passed
                            Else
                                Return False ' failed
                            End If
                    End Select

                Case MsaaRoles.ProgressBar, MsaaRoles.Text
                    If Not ex Is Nothing Then
                        ' Do not have default actions, so verify DISP_E_MEMBERNOTFOUND is returned
                        ' If any other COM result is returned, it is a failure.
                        If ex.ErrorCode <> NativeMethods.DISP_E_MEMBERNOTFOUND Then
                            Throw New Msaa.DefaultActionException("Does not support DefaultAction, so return DISP_E_MEMBERNOTFOUND. Threw the following COM exception " & ex.Message, ex)
                        End If
                    End If

                    resultsLog = Me.ResultsLogFormat("", defaultAction, "Control does not have a default action.")
                    If defaultAction = "" Then
                        Return True ' passed
                    Else
                        Return False ' failed
                    End If

                Case MsaaRoles.List
                    ' determine which type of list we have
                    Select Case typeofList
                        Case ListType.ListBox
                            If Not ex Is Nothing Then
                                If ex.ErrorCode <> NativeMethods.DISP_E_MEMBERNOTFOUND Then
                                    Throw New Msaa.DefaultActionException("Must not support DefaultAction.  Return DISP_E_MEMBERNOTFOUND instead.  Listbox threw COM exception: " & ex.Message, ex)
                                End If
                            End If

                            resultsLog = Me.ResultsLogFormat("", defaultAction, "Listbox does not have a default action.")
                            If defaultAction = "" Then
                                Return True ' passed
                            Else
                                Return False ' failed
                            End If

                        Case ListType.ListView
                            If Not ex Is Nothing Then
                                If ex.ErrorCode <> NativeMethods.DISP_E_MEMBERNOTFOUND Then
                                    Throw New Msaa.DefaultActionException("DefaultAction is not supported. Return DISP_E_MEMBERNOTFOUND.  Threw the following COM exception: " & ex.Message, ex)
                                End If
                            End If

                            resultsLog = Me.ResultsLogFormat("", defaultAction, "Listview does not have a default action.")
                            If defaultAction = "" Then
                                Return True ' passed
                            Else
                                Return False ' failed
                            End If

                        Case ListType.Neither
                            Throw New Msaa.ChildCountException("Cannot verify object with Role=List because it is neither a list box nor a list view")

                        Case Else
                            Throw New Msaa.ChildCountException("Cannot verify object with Role=List because it is neither a list box nor a list view")
                    End Select

                Case MsaaRoles.ListItem
                    ' determine which type of list we have
                    Select Case typeofList

                        Case ListType.ListBox
                            If Not ex Is Nothing Then
                                Throw New Msaa.DefaultActionException("Must supported default action. Return DISP_E_MEMBERNOTFOUND.  Threw the following COM exception: " & ex.Message, ex)
                            End If

                            resultsLog = Me.ResultsLogFormat("Double Click", defaultAction, "Listbox items have a default action of Double Click.")
                            If defaultAction = "Double Click" Then
                                Return True ' passed
                            Else
                                Return False ' failed
                            End If

                        Case ListType.ListView
                            If Not ex Is Nothing Then
                                Throw New Msaa.DefaultActionException("Must supported default action. Return DISP_E_MEMBERNOTFOUND.  Threw the following COM exception: " & ex.Message, ex)
                            End If

                            resultsLog = Me.ResultsLogFormat("Double Click", defaultAction, "Listbox items have a default action of Double Click.")
                            If defaultAction = "Double Click" Then
                                Return True ' passed
                            Else
                                Return False ' failed
                            End If

                        Case ListType.Neither
                            Throw New Msaa.ChildCountException("Cannot verify object with Role=List because it is neither a list box nor a list view")

                        Case Else
                            Throw New Msaa.ChildCountException("Cannot verify object with Role=List because it is neither a list box nor a list view")
                    End Select

                Case MsaaRoles.ComboBox
                    If Not ex Is Nothing Then
                        ' DefaultAction is not supported for the combo box object itself, so it must return DISP_E_MEMBERNOTFOUND
                        ' however, if any other COM result is returned, it is a failure.
                        If ex.ErrorCode <> NativeMethods.DISP_E_MEMBERNOTFOUND Then
                            Throw New Msaa.DefaultActionException("Default action is not supported. Return DISP_E_MEMBERNOTFOUND. Threw the following COM exception " & ex.Message, ex)
                        End If
                    End If

                    resultsLog = Me.ResultsLogFormat("", defaultAction, "Combo box window should not support DefaultAction")
                    If defaultAction = "" Then
                        Return True ' passed
                    Else
                        Return False ' failed
                    End If

                Case MsaaRoles.RadioButton
                    ' must support default action
                    If Not ex Is Nothing Then
                        Throw New Msaa.DefaultActionException("Must support DefaultAction.  Threw COM exception: " & ex.Message, ex)
                    End If

                    resultsLog = Me.ResultsLogFormat("Click", defaultAction, "Radio buttons have a default action of Check.")
                    If defaultAction = "Check" Then
                        Return True ' passed
                    Else
                        Return False ' failed
                    End If

                Case Else
                    resultsLog = "unable to perform verifications on control of role type " & Me.RoleText
                    Return False
            End Select
        End Function

        Public Function VerifyKeyboardShortcut(ByRef resultsLog As String, ByVal expectedKeyboardShortcut As String, ByVal typeofList As ListType) As Boolean
            ' Verify input to these functions
            resultsLog = ""
            If typeofList < 0 OrElse typeofList > 2 Then
                Throw New Msaa.ChildCountException("Invalid argument ListType passed in.  Cannot continue with verifications")
            End If

            Dim keyboardShortcut As String = ""
            Dim ex As System.Runtime.InteropServices.COMException

            Try
                Dim aaObject As Accessibility.IAccessible = Me.IAccessible
                keyboardShortcut = aaObject.accKeyboardShortcut(Me.ChildID)
            Catch ex
                ' catch all exceptions here.  Let MsaaVerify handle it, since msaa verifications cannot be performed
            End Try

            Select Case Me.Role

                Case MsaaRoles.StaticText
                    If Not ex Is Nothing Then
                        ' According to docs, static text is supposed to have a KeyboardShortcut, but most of the time static text doesn't have one
                        ' if any other COM result besides DISP_E_MEMBERNOTFOUND is returned, it is a failure. Testcase must catch KeyboardShortcutException type
                        If ex.ErrorCode <> NativeMethods.DISP_E_MEMBERNOTFOUND Then
                            Throw New Msaa.KeyboardShortcutException("Threw following COM error code: " & ex.Message, ex)
                        End If
                    End If

                    If Me.Caption = "" Then
                        Throw New Msaa.KeyboardShortcutException("Caption is Null. Cannot verify keyboard shortcut")
                    End If

                    ' the keyboard shortcut for a static text's control is the access key or mnemonic
                    ' there can be only one... & in a control's caption, so handle the &&&StaticText case
                    Dim index As Integer = Me.Caption().LastIndexOf("&")
                    Dim accessKey As String = ""
                    If index > -1 Then
                        accessKey = "Alt+" + Me.Caption().Substring(index + 1, 1)
                    End If

                    ' if both keyboardShortcut and accessKey are Null, that's okay.  Either DISP_E_MEMBERNOTFOUND or S_Ok w/ Null BSTR or S_FALSE is acceptable
                    ' not a requirement for all static text or labels to support keyboard shortcut
                    If keyboardShortcut = accessKey Then
                        If keyboardShortcut = "" Then
                            ' I'm not going to consider this scenario a bug
                            resultsLog = Me.ResultsLogFormat(accessKey, keyboardShortcut, "If this static text labels a control, it must have a keyboard shortcut.")
                        Else
                            resultsLog = Me.ResultsLogFormat(accessKey, keyboardShortcut, "Keyboard shortcut is its mnemonic or underlined letter.")
                        End If
                        Return True ' passed
                    Else
                        resultsLog = Me.ResultsLogFormat(accessKey, keyboardShortcut, "Keyboard shortcut is its mnemonic or underlined letter.")
                        Return False ' failed
                    End If

                Case MsaaRoles.PushButton
                    If Not ex Is Nothing Then
                        ' must support keyboard shortcut.  
                        Throw New Msaa.KeyboardShortcutException("Button must support KeyboardShortcut.  Button threw the following COM error code: " & ex.Message, ex)
                    End If

                    ' check whether this push button belongs to a combo box or is a stand-alone push button
                    ' check parent and grandparent, in case the button has an invisble window wrapper object
                    ' most of the time, a push button parent is a combo box
                    If Me.Parent.Role = MsaaRoles.ComboBox OrElse Me.Parent.Parent.Role = MsaaRoles.ComboBox Then
                        resultsLog = Me.ResultsLogFormat("Alt+Down Arrow", keyboardShortcut, "Keyboard shortcut for combo box push button is Alt+Down Arrow")

                        If keyboardShortcut = "Alt+Down Arrow" Then
                            Return True ' passed
                        Else
                            Return False ' failed
                        End If
                    End If

                    If Me.Caption = "" Then
                        Throw New Msaa.KeyboardShortcutException("Caption is Null. Cannot verify keyboard shortcut")
                    End If

                    ' the keyboard shortcut for a static text's control is the access key or mnemonic
                    ' there can be only one... & in a control's caption, so handle the &&&StaticText case
                    Dim index As Integer = Me.Caption().LastIndexOf("&")
                    Dim accessKey As String = ""
                    If index > -1 Then
                        accessKey = "Alt+" + Me.Caption().Substring(index + 1, 1)
                    End If

                    resultsLog = Me.ResultsLogFormat(accessKey, keyboardShortcut, "Keyboard shortcut is its mnemonic or underlined letter.  Control must have a keyboard shortcut")

                    ' need to perform this check to avoid crashing when calling .ToUpper()
                    If keyboardShortcut = "" Then
                        Return False ' failed
                    ElseIf accessKey = "" Then
                        Return False ' failed
                    End If

                    If keyboardShortcut.ToUpper() = accessKey.ToUpper() Then
                        Return True ' passed
                    Else
                        Return False ' failed
                    End If

                Case MsaaRoles.CheckButton, MsaaRoles.RadioButton
                    If Not ex Is Nothing Then
                        ' must support keyboard shortcut.  
                        Throw New Msaa.KeyboardShortcutException("Button must support KeyboardShortcut.  Button threw the following COM error code: " & ex.Message, ex)
                    End If

                    If Me.Caption = "" Then
                        Throw New Msaa.KeyboardShortcutException("Caption is Null. Cannot verify keyboard shortcut")
                    End If

                    ' the keyboard shortcut for a static text's control is the access key or mnemonic
                    ' there can be only one... & in a control's caption, so handle the &&&StaticText case
                    Dim index As Integer = Me.Caption().LastIndexOf("&")
                    Dim accessKey As String = ""
                    If index > -1 Then
                        accessKey = "Alt+" + Me.Caption().Substring(index + 1, 1)
                    End If

                    resultsLog = Me.ResultsLogFormat(accessKey, keyboardShortcut, "Keyboard shortcut is its mnemonic or underlined letter.  Control must have a keyboard shortcut")

                    ' need to perform this check to avoid crashing when calling .ToUpper()
                    If keyboardShortcut = "" Then
                        Return False ' failed
                    ElseIf accessKey = "" Then
                        Return False ' failed
                    End If

                    If keyboardShortcut.ToUpper() = accessKey.ToUpper() Then
                        Return True ' passed
                    Else
                        Return False ' failed
                    End If

                Case MsaaRoles.ProgressBar, MsaaRoles.StatusBar
                    If Not ex Is Nothing Then
                        ' Does not have keyboard shortcuts, so verify DISP_E_MEMBERNOTFOUND is returned
                        ' If any other COM result is returned, it is a failure. 
                        If ex.ErrorCode <> NativeMethods.DISP_E_MEMBERNOTFOUND Then
                            Throw New Msaa.KeyboardShortcutException("Do not have keyboard shortcuts, so return DISP_E_MEMBERNOTFOUND. Threw the following COM exception " & ex.Message, ex)
                        End If
                    End If

                    resultsLog = Me.ResultsLogFormat("", keyboardShortcut, "Control does not support Keyboard Shortcut.")
                    If keyboardShortcut = "" Then
                        Return True ' passed
                    Else
                        Return False ' failed
                    End If

                Case MsaaRoles.Text

                    If Not ex Is Nothing Then
                        ' Must support KeyboardShortcut
                        Throw New Msaa.KeyboardShortcutException("Threw the following COM exception: " & ex.Message, ex)
                    End If

                    ' user must provide a KeyboardShortcut
                    If expectedKeyboardShortcut = "" Then
                        resultsLog = Me.ResultsLogFormat(expectedKeyboardShortcut, keyboardShortcut, "Control must have a keyboard shortcut", True)
                        Return False ' failed
                    End If

                    ' prepend the Alt+ to the expected shortcut
                    expectedKeyboardShortcut = "Alt+" & expectedKeyboardShortcut

                    resultsLog = Me.ResultsLogFormat(expectedKeyboardShortcut, keyboardShortcut, "KeyboardShortcut matches the user-specified KeyboardShortcut")

                    ' make sure the keyboard shortcut isn't null in order to call ToUpper()
                    If keyboardShortcut = "" Then
                        Return False ' failed
                    End If

                    If keyboardShortcut.ToUpper = expectedKeyboardShortcut.ToUpper Then
                        Return True ' passed
                    Else
                        Return False ' failed
                    End If

                Case MsaaRoles.ComboBox

                    ' user must provide the KeyboardShortcut
                    If expectedKeyboardShortcut = "" Then
                        Throw New Msaa.KeyboardShortcutException("Expected KeyboardShortcut cannot be null!  Cannot verify combo box keyboard shortcut!")
                    End If

                    ' prepend the Alt+ to the expected shortcut
                    expectedKeyboardShortcut = "Alt+" & expectedKeyboardShortcut

                    ' make sure the keyboard shortcut isn't null in order to call ToUpper()
                    If keyboardShortcut = "" Then
                        resultsLog = "KeyboardShortcut is null for combo box"
                        Return False ' failed
                    Else
                        If keyboardShortcut.ToUpper = expectedKeyboardShortcut.ToUpper Then
                            resultsLog = "KeyboardShortcut matches the user specified KeyboardShortcut"
                            Return True ' passed
                        Else
                            resultsLog = "Combo box has an actual KeyboardShortcut of " + keyboardShortcut + " instead of expected " + expectedKeyboardShortcut
                            Return False ' failed
                        End If
                    End If

                Case MsaaRoles.List
                    If Not ex Is Nothing Then
                        ' Must support KeyboardShortcut
                        Throw New Msaa.KeyboardShortcutException("Threw the following COM exception: " & ex.Message, ex)
                    End If

                    ' user must specify a keyboard shortcut
                    If expectedKeyboardShortcut = "" Then
                        resultsLog = Me.ResultsLogFormat(expectedKeyboardShortcut, keyboardShortcut, "Control must have a keyboard shortcut", True)
                        Return False ' failed
                    End If

                    resultsLog = Me.ResultsLogFormat(expectedKeyboardShortcut, keyboardShortcut, "KeyboardShortcut must match the user-specified keyboardShortcut.  Control must have a keyboard shortcut.")

                    ' the keyboardShortcut cannot be null in order to call ToUpper() 
                    If keyboardShortcut = "" Then
                        Return False ' failed
                    End If

                    ' prepend the Alt+ to the expected shortcut
                    expectedKeyboardShortcut = "Alt+" & expectedKeyboardShortcut

                    If keyboardShortcut.ToUpper = expectedKeyboardShortcut.ToUpper Then
                        Return True ' passed
                    Else
                        Return False ' failed
                    End If

                Case MsaaRoles.ListItem
                    If Not ex Is Nothing Then
                        ' Does not have keyboard shortcuts, so verify DISP_E_MEMBERNOTFOUND is returned
                        ' If any other COM result is returned, it is a failure. 
                        If ex.ErrorCode <> NativeMethods.DISP_E_MEMBERNOTFOUND Then
                            Throw New Msaa.KeyboardShortcutException("Listitems do not have keyboard shortcuts, so return DISP_E_MEMBERNOTFOUND. Threw the following COM exception " & ex.Message, ex)
                        End If
                    End If

                    resultsLog = Me.ResultsLogFormat("", keyboardShortcut, "KeyboardShortcut must match the user-specified keyboardShortcut.  Listitems do not have keyboard shortcuts.")

                    If keyboardShortcut = "" Then
                        Return True ' passed
                    Else
                        Return False ' failed
                    End If

                Case Else
                    resultsLog = "unable to perform verifications on control of role type " & Me.RoleText
                    Return False ' failed
            End Select
        End Function

        Public Function VerifyName(ByRef resultsLog As String, ByVal expectedName As String, ByVal typeofList As ListType) As Boolean
            ' Verify input to these functions
            resultsLog = ""
            If typeofList < 0 OrElse typeofList > 2 Then
                Throw New Msaa.ChildCountException("Invalid argument ListType passed in.  Cannot continue with verifications")
            End If

            Dim name As String = ""
            Dim ex As System.Runtime.InteropServices.COMException

            Try
                Dim aaObject As Accessibility.IAccessible = Me.IAccessible
                name = aaObject.accName(Me.ChildID)
            Catch ex
                ' catch all exceptions here.  Let MsaaVerify handle it, since msaa verifications cannot be performed
                ' there are some very rare edge cases (like status bar) where Name may not be supported
            End Try

            Select Case Me.Role

                Case MsaaRoles.StaticText, MsaaRoles.CheckButton, MsaaRoles.RadioButton
                    If Not ex Is Nothing Then
                        Throw New Msaa.NameException("Threw the following COM exception: " & ex.Message, ex)
                    End If

                    ' check whether the caption exists
                    If Me.Caption = "" Then
                        Throw New Msaa.NameException("Caption is null.  Cannot verify name")
                    End If

                    ' if Caption contains &&, just remove one &
                    If Me.Caption.IndexOf("&&") > -1 Then
                        expectedName = Me.Caption.Replace("&&", "&")
                    Else
                        ' if Caption contains & (it can only contain one single &)
                        expectedName = Me.Caption.Replace("&", "")
                    End If

                    ' check whether the control has a name
                    If name = "" Then
                        resultsLog = Me.ResultsLogFormat(expectedName, name, "Control must have a name that matches its caption.")
                        Return False ' failed
                    End If

                    resultsLog = Me.ResultsLogFormat(expectedName, name, "Control must have a name that matches its caption.")

                    ' check whether the AA name matches the caption
                    If name = expectedName Then
                        Return True ' passed
                    Else
                        Return False ' failed
                    End If

                Case MsaaRoles.PushButton

                    If Not ex Is Nothing Then
                        Throw New Msaa.NameException("Threw the following COM exception: " & ex.Message, ex)
                    End If

                    ' check whether this push button belongs to a combo box or is a stand-alone push button
                    ' check parent and grandparent, in case the button has an invisble window wrapper object
                    ' most of the time, a push button parent is a combo box
                    If Me.Parent.Role = MsaaRoles.ComboBox OrElse Me.Parent.Parent.Role = MsaaRoles.ComboBox Then
                        resultsLog = Me.ResultsLogFormat("Open", name, "ComboBox Push Button must have name Open", True)

                        If Me.Name = "Open" Then
                            Return True
                        Else
                            Return False
                        End If
                    End If

                    ' check whether the caption exists
                    If Me.Caption = "" Then
                        Throw New Msaa.NameException("Caption is null.  Cannot verify name")
                    End If

                    ' if Caption contains &&, just remove one &
                    If Me.Caption.IndexOf("&&") > -1 Then
                        expectedName = Me.Caption.Replace("&&", "&")
                    Else
                        ' if Caption contains & (it can only contain one single &)
                        expectedName = Me.Caption.Replace("&", "")
                    End If

                    ' check whether the control has a name
                    If name = "" Then
                        resultsLog = Me.ResultsLogFormat(expectedName, name, "Control must have a name that matches its caption.")
                        Return False ' failed
                    End If

                    resultsLog = Me.ResultsLogFormat(expectedName, name, "Control must have a name that matches its caption.")

                    ' check whether the AA name matches the caption
                    If name = expectedName Then
                        Return True ' passed
                    Else
                        Return False ' failed
                    End If

                Case MsaaRoles.List
                    If Not ex Is Nothing Then
                        ' must support Name
                        Throw New Msaa.NameException("Name must be supported! Threw the following COM exception " & ex.Message, ex)
                    End If

                    ' make sure user specified a valid name
                    If expectedName = "" Then
                        resultsLog = Me.ResultsLogFormat(expectedName, name, "Control must have a name that come from its label", True)
                        Return False ' failed
                    End If

                    resultsLog = Me.ResultsLogFormat(expectedName, name, "Control must have a name that come from its label")

                    If name = expectedName Then
                        Return True ' passed
                    Else
                        Return False ' failed
                    End If

                Case MsaaRoles.ListItem
                    If Not ex Is Nothing Then
                        ' must support Name. 
                        Throw New Msaa.NameException("Name must be supported! Threw the following COM exception " & ex.Message, ex)
                    End If

                    Select Case typeofList

                        Case ListType.ListBox
                            If Not ex Is Nothing Then
                                ' Must support KeyboardShortcut
                                Throw New Msaa.KeyboardShortcutException("Threw the following COM exception: " & ex.Message, ex)
                            End If

                            ' Msaa childIDs are 1-based, so subtract 1
                            Dim listBoxItemText As String = ListboxText(Me.ChildID - 1)

                            resultsLog = Me.ResultsLogFormat(listBoxItemText, name, "Name is the list box item's text")

                            If listBoxItemText = name Then
                                Return True ' passed
                            Else
                                Return False ' failed
                            End If

                        Case ListType.ListView
                            If Not ex Is Nothing Then
                                ' Must support KeyboardShortcut
                                Throw New Msaa.KeyboardShortcutException("Threw the following COM exception: " & ex.Message, ex)
                            End If

                            ' Msaa childIDs are 1-based, so subtract 1
                            Dim listViewItemText As String = ListViewText(Me.ChildID - 1)

                            resultsLog = Me.ResultsLogFormat(listViewItemText, name, "Name is the listview item's text")
                            If listViewItemText = Me.Name Then
                                Return True ' passed
                            Else
                                Return False ' failed
                            End If
                    End Select

                Case MsaaRoles.ProgressBar, MsaaRoles.Text
                    If Not ex Is Nothing Then
                        ' must support Name. 
                        Throw New Msaa.NameException("Name must be supported! Threw the following COM exception " & ex.Message, ex)
                    End If

                    If expectedName = "" Then
                        resultsLog = Me.ResultsLogFormat(expectedName, name, "Control must have a name that come from its label", True)
                    End If

                    resultsLog = Me.ResultsLogFormat(expectedName, name, "Control must have a name that come from its label")
                    If name = expectedName Then
                        Return True ' passed
                    Else
                        Return False ' failed
                    End If

                Case MsaaRoles.StatusBar
                    If Not ex Is Nothing Then
                        ' crazily enough, the status bar object itself does not support the Name property, but it isn't necessarily a bug if it does
                        ' if any other COM result, besides DISP_E_MEMBERNOTFOUND, is returned, it is a failure. Testcase must catch KeyboardShortcutException type
                        If ex.ErrorCode <> NativeMethods.DISP_E_MEMBERNOTFOUND Then
                            Throw New Msaa.NameException("The name property for the Status bar itself is not supported, so return DISP_E_MEMBERNOTFOUND; however, StatusBar threw the following COM exception: " & ex.Message, ex)
                        End If
                    End If

                    ' verify the children's names are the same as their displayed text
                    If Me.ChildCount > 0 Then
                        For index As Integer = 0 To Me.ChildCount - 1
                            Dim panelMsaaName = Me.Child(index).Name
                            If panelMsaaName = "" Then
                                AddMsaaError(resultsLog, "Name is Nothing for Panel at index " & index)
                            ElseIf StatusBarPanelText(index) <> panelMsaaName Then
                                AddMsaaError(resultsLog, "Actual Name is " + name + ", but expected Name is " + StatusBarPanelText(index))
                            End If
                        Next
                    End If

                    If resultsLog = "" Then
                        resultsLog = "Status Bar Panels names match their display text."
                        Return True ' passed
                    Else
                        Return False ' failed
                    End If

                Case MsaaRoles.ComboBox
                    If Not ex Is Nothing Then
                        ' must support Name
                        Throw New Msaa.NameException("Name must be supported! Threw the following COM exception " & ex.Message, ex)
                    End If

                    If expectedName = "" Then
                        resultsLog = Me.ResultsLogFormat(expectedName, name, "Combo Box name comes from its label", True)
                    End If

                    resultsLog = Me.ResultsLogFormat(expectedName, name, "Combo Box name comes from its label")

                    If name = "" Then
                        Return False ' failed
                    End If

                    If name = expectedName Then
                        Return True ' passed
                    Else
                        Return False ' failed
                    End If

                Case Else
                    resultsLog = "unable to perform verifications on control of role type " & Me.RoleText
                    Return False
            End Select
        End Function

        Public Function VerifyParent(ByRef resultsLog As String, ByVal typeofList As ListType) As Boolean
            ' Verify input to these functions
            resultsLog = ""
            If typeofList < 0 OrElse typeofList > 2 Then
                Throw New Msaa.ChildCountException("Invalid argument ListType passed in.  Cannot continue with verifications")
            End If

            Dim msaaObjParent As AccessibleObject
            Try
                Dim aaObject As Accessibility.IAccessible = Me.IAccessible
                If (Me.ChildID = 0) Then
                    msaaObjParent = New AccessibleObject(AccessibleObject:=CType(aaObject.accParent, Accessibility.IAccessible))
                Else
                    msaaObjParent = New AccessibleObject(AccessibleObject:=aaObject)
                End If
            Catch ex As System.Runtime.InteropServices.COMException
                ' regardless of the control, parent must be supported
                Throw New Msaa.ParentException("Parent must be supported! Static Text threw the following COM exception: " & ex.Message, ex)
            End Try

            Select Case Me.Role

                Case MsaaRoles.StaticText, MsaaRoles.CheckButton, MsaaRoles.RadioButton, MsaaRoles.ProgressBar, MsaaRoles.StatusBar, MsaaRoles.List, MsaaRoles.ComboBox

                    Dim errorsFound As Boolean = False

                    'check that the parent's role is Role_System_Window
                    If msaaObjParent.Role <> MsaaRoles.Window Then
                        resultsLog = "Parent Role is not of type WINDOW"
                        errorsFound = True
                    End If

                    'check that the parent's name is the same
                    If msaaObjParent.Name <> Me.Name Then
                        AddMsaaError(resultsLog, "Parent Name is not the same as control name")
                        errorsFound = True
                    End If

                    'make sure we can verify the classname
                    If Me.ClassName = "" Then
                        AddMsaaError(resultsLog, "Class Name is Nothing")
                        errorsFound = True
                    End If

                    If Me.Parent.ClassName = "" Then
                        Throw New Msaa.ParentException("Parent class name is null.  Cannot verify class name")
                    End If

                    'check that the parent's class is the same as the static text's class
                    If Me.Parent.ClassName.ToUpper <> Me.ClassName.ToUpper Then
                        AddMsaaError(resultsLog, "Parent Class is not the same as control class")
                        errorsFound = True
                    End If

                    If resultsLog = "" Then
                        resultsLog = "Control's Parent is a Window that has the same name and classname as the control itself."
                    End If

                    Return Not errorsFound

                Case MsaaRoles.PushButton
                    ' check whether this push button belongs to a combo box or is a stand-alone push button
                    ' check parent and grandparent, in case the button has an invisble window wrapper object
                    ' most of the time, a push button parent is a combo box
                    If Me.Parent.Role = MsaaRoles.ComboBox OrElse Me.Parent.Parent.Role = MsaaRoles.ComboBox Then
                        AddMsaaError(resultsLog, Me.ResultsLogFormat("combo box", Me.Parent.RoleText, "Combobox button's parent is the combo box"))

                        ' a push button is not supposed to have an invisible window wrapper object
                        If Me.Parent.Role = MsaaRoles.ComboBox Then
                            Return True ' passed 
                        Else
                            Return False 'failed
                        End If
                    Else
                        Dim errorsFound As Boolean = False

                        'check that the parent's role is Role_System_Window
                        If msaaObjParent.Role <> MsaaRoles.Window Then
                            resultsLog = "Parent Role is not of type WINDOW"
                            errorsFound = True
                        End If

                        'check that the parent's name is the same
                        If msaaObjParent.Name <> Me.Name Then
                            AddMsaaError(resultsLog, "Parent Name is not the same as control name")
                            errorsFound = True
                        End If

                        'make sure we can verify the classname
                        If Me.ClassName = "" Then
                            AddMsaaError(resultsLog, "Class Name is Nothing")
                            errorsFound = True
                        End If

                        If Me.Parent.ClassName = "" Then
                            Throw New Msaa.ParentException("Parent class name is null.  Cannot verify class name")
                        End If

                        'check that the parent's class is the same as the static text's class
                        If Me.Parent.ClassName.ToUpper <> Me.ClassName.ToUpper Then
                            AddMsaaError(resultsLog, "Parent Class is not the same as control class")
                            errorsFound = True
                        End If

                        If resultsLog = "" Then
                            resultsLog = "Control's Parent is a Window that has the same name and classname as the control itself."
                        End If

                        Return Not errorsFound
                    End If

                Case MsaaRoles.Text
                    ' check whether this text belongs to a combo box or is a stand-alone text
                    ' check parent and grandparent, in case the text has an invisble window wrapper object
                    ' most of the time, a text parent is an invisible wrapper
                    If Me.Parent.Parent.Role = MsaaRoles.ComboBox OrElse Me.Parent.Role = MsaaRoles.ComboBox Then
                        AddMsaaError(resultsLog, Me.ResultsLogFormat("window", Me.Parent.RoleText, "Combobox text's parent is usually an invisible window wrapper"))

                        ' a push button is not supposed to have an invisible window wrapper object
                        If Me.Parent.Role = MsaaRoles.Window Then
                            Return True ' passed 
                        Else
                            Return False 'failed
                        End If
                    Else
                        Dim errorsFound As Boolean = False

                        'check that the parent's role is Role_System_Window
                        If msaaObjParent.Role <> MsaaRoles.Window Then
                            resultsLog = "Parent Role is not of type WINDOW"
                            errorsFound = True
                        End If

                        'check that the parent's name is the same
                        If msaaObjParent.Name <> Me.Name Then
                            AddMsaaError(resultsLog, "Parent Name is not the same as control name")
                            errorsFound = True
                        End If

                        'make sure we can verify the classname
                        If Me.ClassName = "" Then
                            AddMsaaError(resultsLog, "Class Name is Nothing")
                            errorsFound = True
                        End If

                        If Me.Parent.ClassName = "" Then
                            Throw New Msaa.ParentException("Parent class name is null.  Cannot verify class name")
                        End If

                        'check that the parent's class is the same as the static text's class
                        If Me.Parent.ClassName.ToUpper <> Me.ClassName.ToUpper Then
                            AddMsaaError(resultsLog, "Parent Class is not the same as control class")
                            errorsFound = True
                        End If

                        If resultsLog = "" Then
                            resultsLog = "Control's Parent is a Window that has the same name and classname as the control itself."
                        End If

                        Return Not errorsFound
                    End If

                Case MsaaRoles.ListItem
                    AddMsaaError(resultsLog, Me.ResultsLogFormat("list", Me.Parent.RoleText, "Listitem's parent is the list"))

                    If Me.Parent.Role = MsaaRoles.List Then
                        Return True
                    Else
                        Return False
                    End If

                Case Else
                    resultsLog = "unable to perform verifications on control of role type " & Me.RoleText
                    Return False
            End Select

            Return resultsLog = ""
        End Function

        Public Function VerifyRole(ByRef resultsLog As String, ByVal typeofList As ListType) As Boolean
            ' Verify input to these functions
            resultsLog = ""
            If typeofList < 0 OrElse typeofList > 2 Then
                Throw New Msaa.ChildCountException("Invalid argument ListType passed in.  Cannot continue with verifications")
            End If

            Dim roleId As Integer
            Dim ex As System.Runtime.InteropServices.COMException

            Try
                Dim aaObject As Accessibility.IAccessible = Me.IAccessible
                roleId = CInt(aaObject.accRole(Me.ChildID))
            Catch ex
                ' regardless of control, role must be supported
                Throw New Msaa.RoleException("Role must be supported! Static Text threw the following COM exception: " & ex.Message, ex)
            End Try

            Select Case Me.Role

                Case MsaaRoles.StaticText
                    ' a static text control has a role of "text" and a "read-only" state
                    resultsLog = Me.ResultsLogFormat("text", RoleText)

                    If Me.RoleText = "text" Then
                        Return True ' passed
                    Else
                        Return False ' failed
                    End If

                Case MsaaRoles.PushButton
                    resultsLog = Me.ResultsLogFormat("push button", Me.RoleText)

                    If Me.RoleText = "push button" Then
                        Return True ' passed
                    Else
                        Return False ' failed
                    End If

                Case MsaaRoles.CheckButton
                    resultsLog = Me.ResultsLogFormat("check box", RoleText)

                    If Me.RoleText = "check box" Then
                        Return True ' passed
                    Else
                        Return False ' failed
                    End If

                Case MsaaRoles.RadioButton
                    resultsLog = Me.ResultsLogFormat("radio button", RoleText)

                    If Me.RoleText = "radio button" Then
                        Return True ' passed
                    Else
                        Return False ' failed
                    End If

                Case MsaaRoles.ProgressBar
                    resultsLog = Me.ResultsLogFormat("progress bar", RoleText)

                    If Me.RoleText = "progress bar" Then
                        Return True ' passed
                    Else
                        Return False ' failed
                    End If

                Case MsaaRoles.Text
                    resultsLog = Me.ResultsLogFormat("editable text", RoleText)

                    If Me.RoleText = "editable text" Then
                        Return True ' passed
                    Else
                        Return False ' failed
                    End If

                Case MsaaRoles.StatusBar
                    Dim otherErrorsFound As Boolean = False

                    resultsLog = Me.ResultsLogFormat("status bar", Me.RoleText)
                    If Me.RoleText <> "status bar" Then
                        otherErrorsFound = True
                    End If
                    If Me.ChildCount > 0 Then
                        For index As Integer = 0 To Me.ChildCount - 1
                            ' status bar panels are really just text
                            If Me.Child(index).RoleText <> "text" Then
                                AddMsaaError(resultsLog, Me.ResultsLogFormat("text", Me.RoleText))
                                otherErrorsFound = True
                            End If
                        Next
                    End If

                    Return Not otherErrorsFound

                Case MsaaRoles.List
                    resultsLog = Me.ResultsLogFormat("list", RoleText)

                    If Me.RoleText = "list" Then
                        Return True ' passed
                    Else
                        Return False ' failed
                    End If

                Case MsaaRoles.ListItem
                    resultsLog = Me.ResultsLogFormat("list item", RoleText)

                    If Me.RoleText = "list item" Then
                        Return True ' passed
                    Else
                        Return False ' failed
                    End If

                Case MsaaRoles.ComboBox
                    resultsLog = Me.ResultsLogFormat("combo box", RoleText)

                    If Me.RoleText = "combo box" Then
                        Return True ' passed
                    Else
                        Return False ' failed
                    End If

                Case Else
                    resultsLog = "unable to perform verifications on control of role type " & Me.RoleText
                    Return False
            End Select
        End Function

        Public Function VerifyState(ByRef resultsLog As String, ByVal typeofList As ListType) As Boolean
            ' Verify input to these functions
            resultsLog = ""
            If typeofList < 0 OrElse typeofList > 2 Then
                Throw New Msaa.ChildCountException("Invalid argument ListType passed in.  Cannot continue with verifications")
            End If

            Dim stateBit As Integer
            Dim state As Integer

            Try
                Dim aaObject As Accessibility.IAccessible = Me.IAccessible
                state = CInt(aaObject.accState(Me.ChildID))
            Catch ex As System.Runtime.InteropServices.COMException
                ' regardless of control, state must be supported
                Throw New Msaa.StateException("Threw the following COM exception: " & ex.Message, ex)
            End Try

            Select Case Me.Role

                Case MsaaRoles.StaticText
                    ' for each bit, check whether this control should support it as a state.
                    ' we're just verifying whether the correct bit is set, not the state text returned
                    For Each stateBit In [Enum].GetValues(GetType(MsaaStates))
                        If (state And stateBit) = stateBit Then
                            Select Case stateBit
                                Case MsaaStates.Normal
                                Case MsaaStates.ReadOnly
                                Case MsaaStates.Invisible
                                Case Else
                                    resultsLog += Me.StateText + " "
                            End Select
                        End If
                    Next stateBit

                    If resultsLog = "" Then
                        resultsLog = "Control is currently in one of the expected states: Normal, ReadOnly, or Invisible"
                        Return True ' passed
                    Else
                        resultsLog = "Has state(s) " + resultsLog + ", but only these states are supported: normal, readonly, or invisible"
                        Return False ' failed
                    End If

                Case MsaaRoles.PushButton

                    ' for each bit, check whether this control should support it as a state.
                    ' we're just verifying whether the correct bit is set, not the state text returned
                    For Each stateBit In [Enum].GetValues(GetType(MsaaStates))
                        If (state And stateBit) = stateBit Then
                            Select Case stateBit
                                Case MsaaStates.Normal
                                Case MsaaStates.Unavailable
                                Case MsaaStates.Focused
                                Case MsaaStates.Focusable
                                Case MsaaStates.Default
                                Case MsaaStates.Pressed
                                Case Else
                                    resultsLog += Me.StateText + " "
                            End Select
                        End If
                    Next stateBit

                    If resultsLog = "" Then
                        resultsLog = "Control is currently in one of the expected states: Normal, Unavailable, Focused, Focusable, Default, or Pressed"
                        Return True ' passed
                    Else
                        resultsLog = "Control has state(s) " + resultsLog + ", but only these states are supported: normal, unavailable, focused, focusable, Default, or pressed"
                        Return False ' failed
                    End If

                Case MsaaRoles.CheckButton
                    ' for each bit, check whether this control should support it as a state.
                    ' we're just verifying whether the correct bit is set, not the state text returned
                    For Each stateBit In [Enum].GetValues(GetType(MsaaStates))
                        If (state And stateBit) = stateBit Then
                            Select Case stateBit
                                Case MsaaStates.Normal
                                Case MsaaStates.Checked
                                Case MsaaStates.Invisible
                                Case MsaaStates.Focusable
                                Case MsaaStates.Focused
                                Case MsaaStates.Unavailable
                                Case MsaaStates.Mixed
                                Case Else
                                    resultsLog += Me.StateText + " "
                            End Select
                        End If
                    Next stateBit

                    If resultsLog = "" Then
                        resultsLog = "Control is currently in one of the expected states: normal, checked, invisible, focusable, focused, unavailable, or mixed"
                        Return True ' passed
                    Else
                        resultsLog = "Has state(s) " + resultsLog + ", but only these states are supported: normal, checked, invisible, focusable, focused, unavailable, or mixed"
                        Return False ' failed
                    End If

                Case MsaaRoles.ComboBox
                    ' for each bit, check whether this control should support it as a state.
                    ' we're just verifying whether the correct bit is set, not the state text returned
                    For Each stateBit In [Enum].GetValues(GetType(MsaaStates))
                        If (state And stateBit) = stateBit Then
                            Select Case stateBit
                                Case MsaaStates.Normal
                                Case MsaaStates.Unavailable
                                Case MsaaStates.Invisible
                                Case MsaaStates.Focusable
                                Case MsaaStates.Focused
                                Case MsaaStates.Pressed
                                Case MsaaStates.Default
                                Case Else
                                    resultsLog += Me.StateText + " "
                            End Select
                        End If
                    Next stateBit

                    If resultsLog = "" Then
                        resultsLog = "Control is currently in one of the expected states: normal, unavailable, focusable, focused, pressed, default, or invisible"
                        Return True ' passed
                    Else
                        resultsLog = "Control has state(s) " + resultsLog + ", but only these states are supported: normal, unavailable, focusable, focused, pressed, default, or invisible"
                        Return False ' failed
                    End If

                Case MsaaRoles.RadioButton
                    ' for each bit, check whether this control should support it as a state.
                    ' we're just verifying whether the correct bit is set, not the state text returned
                    For Each stateBit In [Enum].GetValues(GetType(MsaaStates))
                        If (state And stateBit) = stateBit Then
                            Select Case stateBit
                                Case MsaaStates.Normal
                                Case MsaaStates.Checked
                                Case MsaaStates.Invisible
                                Case MsaaStates.Focusable
                                Case MsaaStates.Focused
                                Case MsaaStates.Unavailable
                                Case Else
                                    resultsLog += Me.StateText + " "
                            End Select
                        End If
                    Next stateBit

                    If resultsLog = "" Then
                        resultsLog = "Control is currently in one of the expected states: normal, checked, focusable, focused, invisible, or unavailable"
                        Return True ' passed
                    Else
                        resultsLog = "RadioButton has state(s) " + resultsLog + ", but only these states are supported: normal, checked, focusable, focused, invisible, or unavailable"
                        Return False ' failed
                    End If

                Case MsaaRoles.ProgressBar
                    ' for each bit, check whether this control should support it as a state.
                    ' we're just verifying whether the correct bit is set, not the state text returned
                    For Each stateBit In [Enum].GetValues(GetType(MsaaStates))
                        If (state And stateBit) = stateBit Then
                            Select Case stateBit
                                Case MsaaStates.Normal
                                Case MsaaStates.Unavailable
                                Case MsaaStates.Focused
                                Case MsaaStates.Focusable
                                Case MsaaStates.Invisible
                                Case Else
                                    resultsLog += Me.StateText + " "
                            End Select
                        End If
                    Next stateBit

                    If resultsLog = "" Then
                        resultsLog = "Control is currently in one of the expected states: normal, unavailable, focusable, focused, or invisible"
                        Return True ' passed
                    Else
                        resultsLog = "ProgressBar has state(s) " + resultsLog + ", but only these states are supported: normal, unavailable, focusable, focused, or invisible."
                        Return False ' failed
                    End If

                Case MsaaRoles.StatusBar
                    ' for each bit, check whether this control should support it as a state.
                    ' we're just verifying whether the correct bit is set, not the state text returned
                    For Each stateBit In [Enum].GetValues(GetType(MsaaStates))
                        If (state And stateBit) = stateBit Then
                            Select Case stateBit
                                Case MsaaStates.Normal
                                Case MsaaStates.ReadOnly
                                Case MsaaStates.Invisible
                                Case MsaaStates.Unavailable
                                Case MsaaStates.Focusable
                                Case MsaaStates.Focused
                                Case Else
                                    resultsLog += Me.StateText + " "
                            End Select
                        End If
                    Next stateBit

                    If resultsLog = "" Then
                        resultsLog = "Control is currently in one of the expected states: normal, readonly, invisible, unavailable, focusable, or focused"
                        Return True ' passed
                    Else
                        resultsLog = "control has state(s) " + resultsLog + ", but only these states are supported: normal, readonly, invisible, unavailable, focusable, or focused."
                        Return False ' failed
                    End If

                Case MsaaRoles.Text
                    ' for each bit, check whether this control should support it as a state.
                    ' we're just verifying whether the correct bit is set, not the state text returned
                    For Each stateBit In [Enum].GetValues(GetType(MsaaStates))
                        If (Me.State And stateBit) = stateBit Then
                            Select Case stateBit
                                Case MsaaStates.Normal
                                Case MsaaStates.ReadOnly
                                Case MsaaStates.Invisible
                                Case MsaaStates.Focusable
                                Case MsaaStates.Focused
                                Case MsaaStates.Protected
                                Case Else
                                    resultsLog += Me.StateText + " "
                            End Select
                        End If
                    Next stateBit

                    If resultsLog = "" Then
                        resultsLog = "Control is currently in one of the expected states: normal, read only, focusable, focused, invisible, or protected"
                        Return True ' passed
                    Else
                        resultsLog = "Control has state(s) " + resultsLog + ", but only these states are supported: normal, read only, focusable, focused, invisible, or protected"
                        Return False ' failed
                    End If

                Case MsaaRoles.List
                    ' for each bit, check whether this control should support it as a state.
                    ' we're just verifying whether the correct bit is set, not the state text returned
                    For Each stateBit In [Enum].GetValues(GetType(MsaaStates))
                        If (state And stateBit) = stateBit Then
                            Select Case stateBit
                                Case MsaaStates.Normal
                                Case MsaaStates.Invisible
                                Case MsaaStates.Unavailable
                                Case MsaaStates.Focusable
                                Case MsaaStates.Focused
                                Case MsaaStates.OffScreen
                                Case Else
                                    resultsLog += Me.StateText + " "
                            End Select
                        End If
                    Next stateBit

                    If resultsLog = "" Then
                        resultsLog = "Control is currently in one of the expected states: normal, Invisible, Unavailable, Focusable, Focused, OffScreen"
                        Return True ' passed
                    Else
                        resultsLog = "Control has state(s) " + resultsLog + ", but only these states are supported: normal, Invisible, Unavailable, Focusable, Focused, OffScreen."
                        Return False ' failed
                    End If

                Case MsaaRoles.ListItem
                    ' for each bit, check whether this control should support it as a state.
                    ' we're just verifying whether the correct bit is set, not the state text returned
                    For Each stateBit In [Enum].GetValues(GetType(MsaaStates))
                        If (Me.State And stateBit) = stateBit Then
                            Select Case stateBit
                                Case MsaaStates.Normal
                                Case MsaaStates.Invisible
                                Case MsaaStates.Focusable
                                Case MsaaStates.Focused
                                Case MsaaStates.Selectable
                                Case MsaaStates.Selected
                                Case MsaaStates.OffScreen
                                Case MsaaStates.MultiSelectable
                                Case Else
                                    resultsLog += Me.StateText + " "
                            End Select
                        End If
                    Next stateBit

                    If resultsLog = "" Then
                        resultsLog = "Control is currently in one of the expected states: normal, invisible, focusable, focused, selectable, selected, and offscreen"
                        Return True ' passed
                    Else
                        resultsLog = "Control has state(s) " + resultsLog + ", but only these states are supported: normal, invisible, focusable, focused, selectable, selected, and offscreen"
                        Return False ' failed
                    End If

                Case Else
                    resultsLog = "unable to perform verifications on control of role type " & Me.RoleText
                    Return False
            End Select

            Return resultsLog = ""
        End Function

        Public Function VerifyValue(ByRef resultsLog As String, ByVal typeofList As ListType) As Boolean
            ' Verify input to these functions
            resultsLog = ""
            If typeofList < 0 OrElse typeofList > 2 Then
                Throw New Msaa.ChildCountException("Invalid argument ListType passed in.  Cannot continue with verifications")
            End If

            Dim value As String = ""
            Dim ex As System.Runtime.InteropServices.COMException

            Try
                Dim aaObject As Accessibility.IAccessible = Me.IAccessible
                value = aaObject.accValue(Me.ChildID)
            Catch ex
                ' catch all exceptions here.  Let MsaaVerify handle it, since msaa verifications cannot be performed
            End Try

            Select Case Me.Role

                Case MsaaRoles.StaticText, MsaaRoles.PushButton, MsaaRoles.CheckButton, MsaaRoles.RadioButton, MsaaRoles.StatusBar, MsaaRoles.List, MsaaRoles.ListItem
                    If Not ex Is Nothing Then
                        ' these controls do not have values, so verify DISP_E_MEMBERNOTFOUND is returned
                        ' if any other COM result is returned, it is a failure. 
                        If ex.ErrorCode <> NativeMethods.DISP_E_MEMBERNOTFOUND Then
                            Throw New Msaa.ValueException("Value is not supported. Return DISP_E_MEMBERNOTFOUND. Threw the following COM exception: " & ex.Message, ex)
                        End If
                    End If

                    resultsLog = Me.ResultsLogFormat("", value, "Control must not have a value.")
                    If value = "" Then
                        Return True ' passed
                    Else
                        Return False ' failed
                    End If

                Case MsaaRoles.ProgressBar
                    Dim expectedValue As String = Me.Value.ToString

                    resultsLog = Me.ResultsLogFormat("", value, "Progress bar must have a value that matches the percentage completed in progress bar")
                    If value = expectedValue Then
                        Return True ' passed
                    Else
                        Return False ' failed
                    End If

                Case MsaaRoles.Text
                    If Not ex Is Nothing Then
                        ' value must be supported
                        Throw New Msaa.ValueException("Threw the following COM exception: " & ex.Message, ex)
                    End If

                    resultsLog = Me.ResultsLogFormat(Me.TextboxText, value, "Text is the value inside the edit box")
                    If value = Me.TextboxText Then
                        Return True ' passed
                    Else
                        Return False ' failed
                    End If

                Case MsaaRoles.ComboBox
                    If Not ex Is Nothing Then
                        ' value must be supported
                        Throw New Msaa.ValueException("Threw the following COM exception: " & ex.Message, ex)
                    End If

                    resultsLog = Me.ResultsLogFormat(Me.ComboBoxText, value, "Text is the value inside the combo box")
                    If value = ComboBoxText Then
                        Return True ' passed
                    Else
                        Return False ' failed
                    End If

                Case Else
                    resultsLog = "unable to perform verifications on control of role type " & Me.RoleText
                    Return False
            End Select

            Return resultsLog = ""
        End Function

#End Region

        Private Function ResultsLogFormat(ByVal expectedValue As String, ByVal actualValue As String)
            Return ResultsLogFormat(expectedValue, actualValue, "", False)
        End Function

        Private Function ResultsLogFormat(ByVal expectedValue As String, ByVal actualValue As String, ByVal additionalInfo As String)
            Return ResultsLogFormat(expectedValue, actualValue, additionalInfo, False)
        End Function

        Private Function ResultsLogFormat(ByVal expectedValue As String, ByVal actualValue As String, ByVal additionalInfo As String, ByVal userInputCannotBeNull As Boolean)
            If expectedValue = "" Then
                expectedValue = "<null>"
            End If

            If actualValue = "" Then
                actualValue = "<null>"
            End If

            If userInputCannotBeNull Then
                Return "User-specified info cannot be null! Expected " & expectedValue & ". Actual " & actualValue & ". " & additionalInfo
            Else
                Return "Expected " & expectedValue & ". Actual " & actualValue & ". " & additionalInfo
            End If
        End Function

        Private Function ResultsLogFormat(ByVal expectedValue As Integer, ByVal actualValue As Integer, ByVal additionalInfo As String)
            Return "Expected " & expectedValue.ToString & ". Actual " & actualValue.ToString & ". " & additionalInfo
        End Function

        Private Function ResultsLogFormat(ByVal expectedValue As Integer, ByVal actualValue As Integer, ByVal additionalInfo As String, ByVal userInputCannotBeNull As Boolean)
            If Not userInputCannotBeNull Then
                Return ResultsLogFormat(expectedValue, actualValue, additionalInfo)
            End If

            Return "User-specified info cannot be null! Expected " & expectedValue.ToString & ". Actual " & actualValue.ToString & ". " & additionalInfo
        End Function
    End Class

#Region "ActiveAccessibilityCollection"
    Public Class ActiveAccessibilityCollection : Inherits CollectionBase
        Public Sub New()
            MyBase.New()
        End Sub

        Default Public ReadOnly Property Item(ByVal index As Integer) As AccessibleObject
            Get
                Return CType(List(index), AccessibleObject)
            End Get
        End Property

        Public Function Add(ByVal value As AccessibleObject) As Integer
            Return List.Add(value)
        End Function
    End Class
#End Region

End Namespace