Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.

    Friend WithEvents myStaticText As TestApplication.MyCustomControls.MyStaticText
    Friend WithEvents myStatusBar As TestApplication.MyCustomControls.MyStatusBar
    Friend WithEvents myToolbar As TestApplication.MyCustomControls.MyToolbar
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents myButton As MyCustomControls.MyPushButton
    Friend WithEvents CheckBox1 As System.Windows.Forms.CheckBox
    Friend WithEvents myCheckBox As TestApplication.MyCustomControls.MyCheckBox
    Friend WithEvents ComboBox1 As System.Windows.Forms.ComboBox
    Friend WithEvents myComboBox As MyCustomControls.MyComboBox
    Friend WithEvents myComboBox1 As TestApplication.MyCustomControls.MyComboBox
    Friend WithEvents ProgressBar1 As System.Windows.Forms.ProgressBar
    Friend WithEvents myProgressBar As MyCustomControls.MyProgressBar
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents myTextBox As TestApplication.MyCustomControls.MyTextbox
    Friend WithEvents StatusBar1 As System.Windows.Forms.StatusBar
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents myDialog As MyCustomControls.MyDialog
    Friend WithEvents myTreeView As MyCustomControls.MyTreeView
    Friend WithEvents TreeView1 As System.Windows.Forms.TreeView
    Friend WithEvents ListBox1 As System.Windows.Forms.ListBox
    Friend WithEvents myListBox As MyCustomControls.MyListBox

    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.myStatusBar = New TestApplication.MyCustomControls.MyStatusBar
        Me.myTextBox = New TestApplication.MyCustomControls.MyTextbox
        Me.myToolbar = New TestApplication.MyCustomControls.MyToolbar
        Me.Button1 = New System.Windows.Forms.Button
        Me.myButton = New TestApplication.MyCustomControls.MyPushButton
        Me.CheckBox1 = New System.Windows.Forms.CheckBox
        Me.myCheckBox = New TestApplication.MyCustomControls.MyCheckBox
        Me.ComboBox1 = New System.Windows.Forms.ComboBox
        Me.myComboBox1 = New TestApplication.MyCustomControls.MyComboBox
        Me.ProgressBar1 = New System.Windows.Forms.ProgressBar
        Me.myProgressBar = New TestApplication.MyCustomControls.MyProgressBar
        Me.TextBox1 = New System.Windows.Forms.TextBox
        Me.StatusBar1 = New System.Windows.Forms.StatusBar
        Me.Label1 = New System.Windows.Forms.Label
        Me.myStaticText = New TestApplication.MyCustomControls.MyStaticText
        Me.myDialog = New TestApplication.MyCustomControls.MyDialog
        Me.TreeView1 = New System.Windows.Forms.TreeView
        Me.myTreeView = New TestApplication.MyCustomControls.MyTreeView
        Me.ListBox1 = New System.Windows.Forms.ListBox
        Me.myListBox = New TestApplication.MyCustomControls.MyListBox
        Me.SuspendLayout()
        '
        'myStatusBar
        '
        Me.myStatusBar.Location = New System.Drawing.Point(136, 192)
        Me.myStatusBar.Name = "myStatusBar"
        Me.myStatusBar.Size = New System.Drawing.Size(128, 23)
        Me.myStatusBar.TabIndex = 0
        Me.myStatusBar.Text = "Custom Status bar"
        '
        'myTextBox
        '
        Me.myTextBox.Location = New System.Drawing.Point(136, 160)
        Me.myTextBox.Name = "myTextBox"
        Me.myTextBox.Size = New System.Drawing.Size(96, 23)
        Me.myTextBox.TabIndex = 0
        Me.myTextBox.Text = "custom textbox"
        '
        'myToolbar
        '
        Me.myToolbar.Location = New System.Drawing.Point(136, 256)
        Me.myToolbar.Name = "myToolbar"
        Me.myToolbar.Size = New System.Drawing.Size(88, 23)
        Me.myToolbar.TabIndex = 0
        Me.myToolbar.Text = "custom toolbar"
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(8, 8)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(96, 23)
        Me.Button1.TabIndex = 0
        Me.Button1.Text = "Standard Button"
        '
        'myButton
        '
        Me.myButton.Location = New System.Drawing.Point(136, 8)
        Me.myButton.Name = "myButton"
        Me.myButton.Size = New System.Drawing.Size(96, 23)
        Me.myButton.TabIndex = 0
        Me.myButton.Text = "Custom Button"
        '
        'CheckBox1
        '
        Me.CheckBox1.Location = New System.Drawing.Point(8, 40)
        Me.CheckBox1.Name = "CheckBox1"
        Me.CheckBox1.Size = New System.Drawing.Size(96, 32)
        Me.CheckBox1.TabIndex = 1
        Me.CheckBox1.Text = "Standard Checkbox"
        '
        'myCheckBox
        '
        Me.myCheckBox.Location = New System.Drawing.Point(136, 40)
        Me.myCheckBox.Name = "myCheckBox"
        Me.myCheckBox.Size = New System.Drawing.Size(96, 32)
        Me.myCheckBox.TabIndex = 1
        Me.myCheckBox.Text = "Custom Checkbox"
        '
        'ComboBox1
        '
        Me.ComboBox1.Location = New System.Drawing.Point(8, 88)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(121, 21)
        Me.ComboBox1.TabIndex = 2
        Me.ComboBox1.Text = "Standard Combo"
        '
        'myComboBox1
        '
        Me.myComboBox1.Location = New System.Drawing.Point(136, 88)
        Me.myComboBox1.Name = "myComboBox1"
        Me.myComboBox1.Size = New System.Drawing.Size(121, 21)
        Me.myComboBox1.TabIndex = 3
        Me.myComboBox1.Text = "Custom Combo"
        '
        'ProgressBar1
        '
        Me.ProgressBar1.Location = New System.Drawing.Point(8, 128)
        Me.ProgressBar1.Name = "ProgressBar1"
        Me.ProgressBar1.TabIndex = 4
        Me.ProgressBar1.Value = 50
        '
        'myProgressBar
        '
        Me.myProgressBar.Location = New System.Drawing.Point(136, 128)
        Me.myProgressBar.Name = "myProgressBar"
        Me.myProgressBar.Size = New System.Drawing.Size(80, 23)
        Me.myProgressBar.TabIndex = 4
        Me.myProgressBar.Text = "Progress Bar"
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(8, 160)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.TabIndex = 5
        Me.TextBox1.Text = "TextBox1"
        '
        'StatusBar1
        '
        Me.StatusBar1.Location = New System.Drawing.Point(0, 518)
        Me.StatusBar1.Name = "StatusBar1"
        Me.StatusBar1.Size = New System.Drawing.Size(296, 24)
        Me.StatusBar1.TabIndex = 6
        Me.StatusBar1.Text = "StatusBar1"
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(8, 224)
        Me.Label1.Name = "Label1"
        Me.Label1.TabIndex = 7
        Me.Label1.Text = "Label1"
        '
        'myStaticText
        '
        Me.myStaticText.Location = New System.Drawing.Point(136, 224)
        Me.myStaticText.Name = "myStaticText"
        Me.myStaticText.Size = New System.Drawing.Size(108, 23)
        Me.myStaticText.TabIndex = 7
        Me.myStaticText.Text = "Custom StaticText"
        '
        'myDialog
        '
        Me.myDialog.Location = New System.Drawing.Point(136, 288)
        Me.myDialog.Name = "myDialog"
        Me.myDialog.Size = New System.Drawing.Size(108, 23)
        Me.myDialog.TabIndex = 8
        Me.myDialog.Text = "Dialog"
        '
        'TreeView1
        '
        Me.TreeView1.ImageIndex = -1
        Me.TreeView1.Location = New System.Drawing.Point(8, 328)
        Me.TreeView1.Name = "TreeView1"
        Me.TreeView1.Nodes.AddRange(New System.Windows.Forms.TreeNode() {New System.Windows.Forms.TreeNode("", New System.Windows.Forms.TreeNode() {New System.Windows.Forms.TreeNode("Node0", New System.Windows.Forms.TreeNode() {New System.Windows.Forms.TreeNode("Node1", New System.Windows.Forms.TreeNode() {New System.Windows.Forms.TreeNode("Node2")})})}), New System.Windows.Forms.TreeNode("Node0"), New System.Windows.Forms.TreeNode("Node1"), New System.Windows.Forms.TreeNode("Node2")})
        Me.TreeView1.SelectedImageIndex = -1
        Me.TreeView1.TabIndex = 9
        '
        'myTreeView
        '
        Me.myTreeView.Location = New System.Drawing.Point(136, 358)
        Me.myTreeView.Name = "myTreeView"
        Me.myTreeView.Size = New System.Drawing.Size(108, 23)
        Me.myTreeView.TabIndex = 10
        Me.myTreeView.Text = "Tree View"
        '
        'ListBox1
        '
        Me.ListBox1.Items.AddRange(New Object() {"fafafafa", "aafafafafa"})
        Me.ListBox1.Location = New System.Drawing.Point(16, 440)
        Me.ListBox1.Name = "ListBox1"
        Me.ListBox1.Size = New System.Drawing.Size(104, 30)
        Me.ListBox1.TabIndex = 11
        '
        'myListBox
        '
        Me.myListBox.Location = New System.Drawing.Point(136, 440)
        Me.myListBox.Name = "myListBox"
        Me.myListBox.Size = New System.Drawing.Size(104, 30)
        Me.myListBox.TabIndex = 11
        Me.myListBox.Text = "ListBox"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(296, 542)
        Me.Controls.Add(Me.ListBox1)
        Me.Controls.Add(Me.TreeView1)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.StatusBar1)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.ProgressBar1)
        Me.Controls.Add(Me.ComboBox1)
        Me.Controls.Add(Me.CheckBox1)
        Me.Controls.Add(Me.myCheckBox)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.myButton)
        Me.Controls.Add(Me.myComboBox1)
        Me.Controls.Add(Me.myProgressBar)
        Me.Controls.Add(Me.myTextBox)
        Me.Controls.Add(Me.myStatusBar)
        Me.Controls.Add(Me.myStaticText)
        Me.Controls.Add(Me.myToolbar)
        Me.Controls.Add(Me.myDialog)
        Me.Controls.Add(Me.myTreeView)
        Me.Controls.Add(Me.myListBox)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)

    End Sub

#End Region

End Class
