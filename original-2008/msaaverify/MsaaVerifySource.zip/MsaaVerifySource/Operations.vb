Imports System.Text
Imports System.IO
Imports System.CodeDom
Imports System.CodeDom.Compiler
Imports MsaaVerify.MsaaVerify.Msaa

Namespace MsaaVerify

    Public Class Operations

#Region "Constants"
        Const ListViewClassName As String = "listview"
        Const ListBoxClassName As String = "listbox"
        Private Const NumberOfMsaaVerifications As Integer = 9

        Private Enum ResultsType
            ChildCount = 0
            DefaultAction = 1
            Description = 2
            KeyboardShortcut = 3
            Name = 4
            Parent = 5
            Role = 6
            State = 7
            Value = 8
        End Enum

#End Region

#Region "Private Variables"
        Private m_msaaObjectsFound As ArrayList
        Private m_totalNumberPassed As Integer
        Private m_totalNumberFailed As Integer
        Private m_accVerifyForm As MsaaVerifyForm
        Private m_cachedComboBoxName As String
        Private m_cachedComboBoxKeyboardShortcut As String
#End Region

#Region "Constructor"
        Public Sub New(ByRef form As MsaaVerifyForm)
            ResetNumericalResults()
            m_msaaObjectsFound = New ArrayList
            m_accVerifyForm = form
        End Sub
#End Region

#Region "Public or Friend Methods"

        Friend Function GenerateMsaaInfo(ByVal foundMsaaObject As AccessibleObject, ByVal hwnd As Integer) As ArrayList
            ' clear collection from any previous searches
            m_msaaObjectsFound.Clear()

            Try
                ' handle special cases 
                If foundMsaaObject.Parent.Role = MsaaRoles.StatusBar Then
                    ' for statusbar roles, the parent is the role we are interested in 
                    m_msaaObjectsFound.Add(foundMsaaObject.Parent)

                ElseIf foundMsaaObject.Role = MsaaRoles.List Then
                    ' add the simple elements for a list or outline to the collection
                    m_msaaObjectsFound.Add(foundMsaaObject)

                    If foundMsaaObject.ListViewHasHeader Then
                        ' ChildCount is 1-based, so subtract 1
                        ' It has an extra child wrapping the header columns, which we don't test currently, so subtract another 1
                        For index As Integer = 0 To foundMsaaObject.ChildCount - 2
                            m_msaaObjectsFound.Add(foundMsaaObject.Child(index))
                        Next
                    Else
                        ' ChildCount is 1-based, so subtract 1
                        For index As Integer = 0 To foundMsaaObject.ChildCount - 1
                            m_msaaObjectsFound.Add(foundMsaaObject.Child(index))
                        Next
                    End If

                ElseIf foundMsaaObject.Role = MsaaRoles.ListItem Then
                    ' if the user captures a list item or outline item, add the parent and then all the children
                    Dim parentMsaaObject As AccessibleObject = foundMsaaObject.Parent ' cache the parent
                    m_msaaObjectsFound.Add(parentMsaaObject)

                    If parentMsaaObject.ListViewHasHeader Then
                        ' ChildCount is 1-based, so subtract 1
                        ' It has an extra child wrapping the header columns, which we don't test currently, so subtract another 1
                        For index As Integer = 0 To parentMsaaObject.ChildCount - 2
                            m_msaaObjectsFound.Add(parentMsaaObject.Child(index))
                        Next
                    Else
                        ' ChildCount is 1-based, so subtract 1
                        For index As Integer = 0 To parentMsaaObject.ChildCount - 1
                            m_msaaObjectsFound.Add(parentMsaaObject.Child(index))
                        Next
                    End If

                ElseIf foundMsaaObject.Role = MsaaRoles.ComboBox Then
                    m_msaaObjectsFound.Add(foundMsaaObject)

                    ' add combobox children text, read-only text (statictext), button, and list, because those are the roles MsaaVerify can verify
                    ' ChildCount is 1-based, so subtract 1
                    For index As Integer = 0 To foundMsaaObject.ChildCount - 1

                        ' make sure we're adding only acceptable role types that we can verify
                        If foundMsaaObject.Child(index).Role = MsaaRoles.StaticText _
                        OrElse foundMsaaObject.Child(index).Role = MsaaRoles.Text _
                        OrElse foundMsaaObject.Child(index).Role = MsaaRoles.PushButton _
                        OrElse foundMsaaObject.Child(index).Role = MsaaRoles.List Then
                            m_msaaObjectsFound.Add(foundMsaaObject.Child(index))
                        End If

                        ' if the combo box has either a Window or a List as a child, add their children to be verified
                        If foundMsaaObject.Child(index).Role = MsaaRoles.Window _
                            OrElse foundMsaaObject.Child(index).Role = MsaaRoles.List Then

                            ' add the child or children found from under the window or the list
                            For jindex As Integer = 0 To foundMsaaObject.Child(index).ChildCount - 1

                                ' make sure we're adding only acceptable role types that we can verify
                                If foundMsaaObject.Child(index).Role = MsaaRoles.StaticText _
                                OrElse foundMsaaObject.Child(index).Child(jindex).Role = MsaaRoles.Text _
                                OrElse foundMsaaObject.Child(index).Child(jindex).Role = MsaaRoles.PushButton _
                                OrElse foundMsaaObject.Child(index).Child(jindex).Role = MsaaRoles.List _
                                OrElse foundMsaaObject.Child(index).Child(jindex).Role = MsaaRoles.ListItem Then
                                    m_msaaObjectsFound.Add(foundMsaaObject.Child(index).Child(jindex))
                                End If

                                ' at this point, the only great-grandchildren we're interested in are the ListItems
                                If foundMsaaObject.Child(index).Child(jindex).Role = MsaaRoles.List Then
                                    ' add the children of the listview
                                    For kindex As Integer = 0 To foundMsaaObject.Child(index).Child(jindex).ChildCount - 1
                                        ' add all list view children, because we'll verify that they have the correct roles
                                        m_msaaObjectsFound.Add(foundMsaaObject.Child(index).Child(jindex).Child(kindex))
                                    Next
                                End If
                            Next
                        End If
                    Next

                ElseIf foundMsaaObject.Role = MsaaRoles.Text OrElse foundMsaaObject.Role = MsaaRoles.PushButton Then
                    ' check whether we captured a combo box or just an edit box or a push button
                    If foundMsaaObject.Parent.Role = MsaaRoles.ComboBox Then
                        ' add the parent, which is a combo box, to the list for verification
                        m_msaaObjectsFound.Add(foundMsaaObject.Parent)

                        ' now add the rest of the combo box children
                        ' add combobox children text, read-only text (statictext), button, and list, because those are the roles MsaaVerify can verify
                        ' ChildCount is 1-based, so subtract 1
                        For index As Integer = 0 To foundMsaaObject.Parent.ChildCount - 1

                            ' make sure we're adding only acceptable role types that we can verify
                            If foundMsaaObject.Parent.Child(index).Role = MsaaRoles.StaticText _
                            OrElse foundMsaaObject.Parent.Child(index).Role = MsaaRoles.Text _
                            OrElse foundMsaaObject.Parent.Child(index).Role = MsaaRoles.PushButton _
                            OrElse foundMsaaObject.Parent.Child(index).Role = MsaaRoles.List Then
                                m_msaaObjectsFound.Add(foundMsaaObject.Parent.Child(index))
                            End If

                            ' if the combo box has either a Window or a List as a child, add their children to be verified
                            If foundMsaaObject.Parent.Child(index).Role = MsaaRoles.Window _
                                OrElse foundMsaaObject.Parent.Child(index).Role = MsaaRoles.List Then

                                ' add the child or children found from under the window or the list
                                For jindex As Integer = 0 To foundMsaaObject.Parent.Child(index).ChildCount - 1

                                    ' make sure we're adding only acceptable role types that we can verify
                                    If foundMsaaObject.Parent.Child(index).Role = MsaaRoles.StaticText _
                                    OrElse foundMsaaObject.Parent.Child(index).Child(jindex).Role = MsaaRoles.Text _
                                    OrElse foundMsaaObject.Parent.Child(index).Child(jindex).Role = MsaaRoles.PushButton _
                                    OrElse foundMsaaObject.Parent.Child(index).Child(jindex).Role = MsaaRoles.List _
                                    OrElse foundMsaaObject.Parent.Child(index).Child(jindex).Role = MsaaRoles.ListItem Then
                                        m_msaaObjectsFound.Add(foundMsaaObject.Parent.Child(index).Child(jindex))
                                    End If

                                    ' at this point, the only great-grandchildren we're interested in are the ListItems
                                    If foundMsaaObject.Parent.Child(index).Child(jindex).Role = MsaaRoles.List Then
                                        ' add the children of the listview
                                        For kindex As Integer = 0 To foundMsaaObject.Parent.Child(index).Child(jindex).ChildCount - 1
                                            ' add all list view children, because we'll verify that they have the correct roles
                                            m_msaaObjectsFound.Add(foundMsaaObject.Parent.Child(index).Child(jindex).Child(kindex))
                                        Next
                                    End If
                                Next
                            End If
                        Next
                    ElseIf foundMsaaObject.Parent.Parent.Role = MsaaRoles.ComboBox Then
                        ' add the grandparent, because there's a Window wrapper between the combobox and the edit box
                        m_msaaObjectsFound.Add(foundMsaaObject.Parent.Parent)

                        ' add combobox children text, read-only text (statictext), button, and list, because those are the roles MsaaVerify can verify
                        ' ChildCount is 1-based, so subtract 1
                        For index As Integer = 0 To foundMsaaObject.Parent.Parent.ChildCount - 1

                            ' make sure we're adding only acceptable role types that we can verify
                            If foundMsaaObject.Parent.Parent.Child(index).Role = MsaaRoles.StaticText _
                            OrElse foundMsaaObject.Parent.Parent.Child(index).Role = MsaaRoles.Text _
                            OrElse foundMsaaObject.Parent.Parent.Child(index).Role = MsaaRoles.PushButton _
                            OrElse foundMsaaObject.Parent.Parent.Child(index).Role = MsaaRoles.List Then
                                m_msaaObjectsFound.Add(foundMsaaObject.Parent.Parent.Child(index))
                            End If

                            ' if the combo box has either a Window or a List as a child, add their children to be verified
                            If foundMsaaObject.Parent.Parent.Child(index).Role = MsaaRoles.Window _
                                OrElse foundMsaaObject.Parent.Parent.Child(index).Role = MsaaRoles.List Then

                                ' add the child or children found from under the window or the list
                                For jindex As Integer = 0 To foundMsaaObject.Parent.Parent.Child(index).ChildCount - 1

                                    ' make sure we're adding only acceptable role types that we can verify
                                    If foundMsaaObject.Parent.Parent.Child(index).Role = MsaaRoles.StaticText _
                                    OrElse foundMsaaObject.Parent.Parent.Child(index).Child(jindex).Role = MsaaRoles.Text _
                                    OrElse foundMsaaObject.Parent.Parent.Child(index).Child(jindex).Role = MsaaRoles.PushButton _
                                    OrElse foundMsaaObject.Parent.Parent.Child(index).Child(jindex).Role = MsaaRoles.List _
                                    OrElse foundMsaaObject.Parent.Parent.Child(index).Child(jindex).Role = MsaaRoles.ListItem Then
                                        m_msaaObjectsFound.Add(foundMsaaObject.Parent.Parent.Child(index).Child(jindex))
                                    End If

                                    ' at this point, the only great-grandchildren we're interested in are the ListItems
                                    If foundMsaaObject.Parent.Parent.Child(index).Child(jindex).Role = MsaaRoles.List Then
                                        ' add the children of the listview
                                        For kindex As Integer = 0 To foundMsaaObject.Parent.Parent.Child(index).Child(jindex).ChildCount - 1
                                            ' add all list view children, because we'll verify that they have the correct roles
                                            m_msaaObjectsFound.Add(foundMsaaObject.Parent.Parent.Child(index).Child(jindex).Child(kindex))
                                        Next
                                    End If
                                Next
                            End If
                        Next
                    Else
                        ' just a simple edit box or a push button
                        m_msaaObjectsFound.Add(foundMsaaObject)
                    End If

                ElseIf Not foundMsaaObject.Role = MsaaRoles.Window Then
                    'if it's not a window object, add the object we found to the list
                    m_msaaObjectsFound.Add(foundMsaaObject)

                ElseIf foundMsaaObject.Role = MsaaRoles.Window Then
                    ' do what we can to add it to the list
                    m_msaaObjectsFound.Add(foundMsaaObject.Child(3))
                End If

            Catch ex As Exception
                ' while trying to identify the AA object, one of its methods threw an exception
                ' since we can't further identify it, just add it to the list in hopes we can test for it.
                m_msaaObjectsFound.Add(foundMsaaObject)
            End Try

            Return m_msaaObjectsFound
        End Function

        Public Function VerifyMsaaObjects()
            ' this collection holds all possible objects that are verified.  
            Dim msaaObjectsVerifiedContainer As New Collection

            ' the individual msaaObject to test
            Dim msaaObject As AccessibleObject

            ' location in the tree view
            Dim treeViewIndex As Integer = 0

            ' the error Log 
            Dim errorLog As String = ""

            ' for each AA object in the TreeView of Found AA objects to test
            For Each msaaObject In m_msaaObjectsFound
                ' reset the errorLog for each new verificaton
                errorLog = ""

                ' we test based on role - if the role is wrong, expect a high failure rate
                Select Case msaaObject.Role

                    Case MsaaRoles.StaticText, MsaaRoles.PushButton, MsaaRoles.CheckButton, MsaaRoles.RadioButton, MsaaRoles.StatusBar
                        VerifyMsaaProperties(msaaObject, errorLog, treeViewIndex)

                    Case MsaaRoles.ComboBox
                        m_cachedComboBoxName = InputBox("Please enter expected MSAA Name.  The name comes from the label or static text that immediately precedes the control in tab order:")
                        m_cachedComboBoxKeyboardShortcut = InputBox("Please enter expected keyboard shortcut:  Alt+")
                        VerifyMsaaProperties(msaaObject, errorLog, treeViewIndex, m_cachedComboBoxName, m_cachedComboBoxKeyboardShortcut)

                    Case MsaaRoles.Text
                        ' if it is a text box that belongs to a combo box, assume that the user has already entered the info for name and keyboard shortcut
                        ' we can make this assumption because the combo box itself is always added first
                        Try
                            If msaaObject.Parent.Role = MsaaRoles.ComboBox OrElse msaaObject.Parent.Parent.Role = MsaaRoles.ComboBox Then
                                VerifyMsaaProperties(msaaObject, errorLog, treeViewIndex, Me.m_cachedComboBoxName, Me.m_cachedComboBoxKeyboardShortcut)
                            Else
                                VerifyMsaaProperties(msaaObject, errorLog, treeViewIndex, InputBox("Please enter expected MSAA Name.  The name comes from the label or static text that immediately precedes the control in tab order:"), InputBox("Please enter expected keyboard shortcut:  Alt+"))
                            End If
                        Catch ex As Exception
                            ' it's possible that the object doesn't support parent or role, so catch any exceptions
                            ' assume the text box doesn't belong to a combo box if it doesn't support parent
                            VerifyMsaaProperties(msaaObject, errorLog, treeViewIndex, InputBox("Please enter expected MSAA Name.  The name comes from the label or static text that immediately precedes the control in tab order:"), InputBox("Please enter expected keyboard shortcut:  Alt+"))
                        End Try

                    Case MsaaRoles.ProgressBar
                        VerifyMsaaProperties(msaaObject, errorLog, treeViewIndex, InputBox("Please enter expected MSAA Name.  The name comes from the label or static text that immediately precedes the control in tab order:"))

                    Case MsaaRoles.List
                        ' must determine whether we are dealing with a list view or a list box
                        ' msaa reports both as the same role: "List" grr. argh.
                        Dim lowercaseClassName As String = msaaObject.ClassName.ToLower
                        If lowercaseClassName.IndexOf(ListBoxClassName) >= 0 Then
                            ' it's a list box
                            ' if it is a list box that belongs to a combo box, assume that the user has already entered the info for name and keyboard shortcut
                            ' we can make this assumption because the combo box itself is always added first
                            Try
                                If msaaObject.Parent.Role = MsaaRoles.ComboBox OrElse msaaObject.Parent.Parent.Role = MsaaRoles.ComboBox Then
                                    Me.VerifyMsaaProperties(msaaObject, errorLog, treeViewIndex, m_cachedComboBoxName, m_cachedComboBoxKeyboardShortcut, "", ListType.ListBox)
                                Else
                                    Me.VerifyMsaaProperties(msaaObject, errorLog, treeViewIndex, InputBox("Please enter expected MSAA Name.  The name comes from the label or static text that immediately precedes the control in tab order:"), InputBox("Please enter the expected Keyboard Shortcut:  Alt+"), "", ListType.ListBox)
                                End If
                            Catch ex As Exception
                                ' it's possible that the object doesn't support parent or role, so catch any exceptions
                                ' assume the list box does not belong to a combo box
                                Me.VerifyMsaaProperties(msaaObject, errorLog, treeViewIndex, InputBox("Please enter expected MSAA Name.  The name comes from the label or static text that immediately precedes the control in tab order:"), InputBox("Please enter the expected Keyboard Shortcut:  Alt+"), "", ListType.ListBox)
                            End Try
                        ElseIf lowercaseClassName.IndexOf(ListViewClassName) >= 0 Then
                            ' it's a list view
                            ' if it is a list view that belongs to a combo box, assume that the user has already entered the info for name and keyboard shortcut
                            ' we can make this assumption because the combo box itself is always added first
                            Try
                                If msaaObject.Parent.Role = MsaaRoles.ComboBox OrElse msaaObject.Parent.Parent.Role = MsaaRoles.ComboBox Then
                                    Me.VerifyMsaaProperties(msaaObject, errorLog, treeViewIndex, m_cachedComboBoxName, m_cachedComboBoxKeyboardShortcut, "", ListType.ListBox)
                                Else
                                    Me.VerifyMsaaProperties(msaaObject, errorLog, treeViewIndex, InputBox("Please enter expected MSAA Name.  The name comes from the label or static text that immediately precedes the control in tab order:"), InputBox("Please enter the expected Keyboard Shortcut:  Alt+"), "", ListType.ListView)
                                End If
                            Catch ex As Exception
                                ' it's possible that the object doesn't support parent or role, so catch any exceptions
                                ' assume the list view does not belong to a combo box
                                Me.VerifyMsaaProperties(msaaObject, errorLog, treeViewIndex, InputBox("Please enter expected MSAA Name.  The name comes from the label or static text that immediately precedes the control in tab order:"), InputBox("Please enter the expected Keyboard Shortcut:  Alt+"), "", ListType.ListView)
                            End Try
                        Else
                            ' it's probably better to prompt the user in the case, but let's take a guess.  ListViews are more popular
                            ' if it is a list view that belongs to a combo box, assume that the user has already entered the info for name and keyboard shortcut
                            ' we can make this assumption because the combo box itself is always added first
                            Try
                                If msaaObject.Parent.Role = MsaaRoles.ComboBox OrElse msaaObject.Parent.Parent.Role = MsaaRoles.ComboBox Then
                                    Me.VerifyMsaaProperties(msaaObject, errorLog, treeViewIndex, m_cachedComboBoxName, m_cachedComboBoxKeyboardShortcut, "", ListType.ListBox)
                                Else
                                    Me.VerifyMsaaProperties(msaaObject, errorLog, treeViewIndex, InputBox("Please enter expected MSAA Name.  The name comes from the label or static text that immediately precedes the control in tab order:"), InputBox("Please enter the expected Keyboard Shortcut:  Alt+"), "", ListType.ListView)
                                End If
                            Catch ex As Exception
                                ' it's possible that the object doesn't support parent or role, so catch any exceptions
                                ' assume the list view does not belong to a combo box
                                Me.VerifyMsaaProperties(msaaObject, errorLog, treeViewIndex, InputBox("Please enter expected MSAA Name.  The name comes from the label or static text that immediately precedes the control in tab order:"), InputBox("Please enter the expected Keyboard Shortcut:  Alt+"), "", ListType.ListView)
                            End Try
                        End If

                    Case MsaaRoles.ListItem
                        ' must determine whether we are dealing with a list view item or a list box item
                        ' msaa reports both as the same role: "List"
                        ' for consistency, use the parent, so we're either completely right or completely wrong in our guess
                        Dim lowercaseClassName As String = msaaObject.Parent.ClassName.ToLower
                        If lowercaseClassName.IndexOf(ListBoxClassName) >= 0 Then
                            ' it's a list box item
                            Me.VerifyMsaaProperties(msaaObject, errorLog, treeViewIndex, "", "", "", ListType.ListBox)
                        ElseIf lowercaseClassName.IndexOf(ListViewClassName) >= 0 Then
                            ' it's a list view item
                            Me.VerifyMsaaProperties(msaaObject, errorLog, treeViewIndex, "", "", "", ListType.ListView)
                        Else
                            ' it's probably better to prompt the user in the case, but let's take a guess.  ListViews are more popular
                            Me.VerifyMsaaProperties(msaaObject, errorLog, treeViewIndex, "", "", "", ListType.ListView)
                        End If

                    Case Else
                        Dim currentText As String = Me.m_accVerifyForm.TreeView1.Nodes(treeViewIndex).Text
                        Me.m_accVerifyForm.TreeView1.Nodes(treeViewIndex).Text = currentText & " (Results: Not Yet Implemented)"
                        Me.m_accVerifyForm.TreeView1.Nodes(treeViewIndex).ForeColor = System.Drawing.Color.Blue
                End Select
                treeViewIndex += 1
            Next

            Me.ResetNumericalResults()
        End Function
#End Region

#Region "Private Methods"

        Private Overloads Sub VerifyMsaaProperties(ByVal msaaObject As AccessibleObject, ByVal errorLog As String, ByVal treeViewIndex As Integer)
            VerifyMsaaProperties(msaaObject, errorLog, treeViewIndex, "", "", "", ListType.Neither)
        End Sub

        Private Overloads Sub VerifyMsaaProperties(ByVal msaaObject As AccessibleObject, ByVal errorLog As String, ByVal treeViewIndex As Integer, ByVal expectedName As String)
            VerifyMsaaProperties(msaaObject, errorLog, treeViewIndex, expectedName, "", "", ListType.Neither)
        End Sub

        Private Overloads Sub VerifyMsaaProperties(ByVal msaaObject As AccessibleObject, ByVal errorLog As String, ByVal treeViewIndex As Integer, ByVal expectedName As String, ByVal expectedKeyboardShortcut As String)
            VerifyMsaaProperties(msaaObject, errorLog, treeViewIndex, expectedName, expectedKeyboardShortcut, "", ListType.Neither)
        End Sub

        Private Overloads Sub VerifyMsaaProperties(ByVal msaaObject As AccessibleObject, ByVal errorLog As String, ByVal treeViewIndex As Integer, ByVal expectedName As String, ByVal expectedKeyboardShortcut As String, ByVal expectedDescription As String, ByVal typeofList As ListType)
            Dim numberPassed As Integer = 0
            Dim numberFailed As Integer = 0

            ' begin childCount verification
            errorLog = ""
            Dim childCountPassed As Boolean = False ' always fail by default to avoid false positives
            Try
                childCountPassed = msaaObject.VerifyChildCount(errorLog, typeofList)
                If childCountPassed Then
                    Me.m_accVerifyForm.TreeView1.Nodes(treeViewIndex).Nodes.Add(New TreeNode("ChildCount Passed: " & errorLog))
                Else
                    Me.m_accVerifyForm.TreeView1.Nodes(treeViewIndex).Nodes.Add(New TreeNode("ChildCount Failure: " & errorLog))
                End If
            Catch ChildCountE As ChildCountException
                Me.m_accVerifyForm.TreeView1.Nodes(treeViewIndex).Nodes.Add(New TreeNode("ChildCount Failure: " & ChildCountE.Message))
            Catch ex As Exception
                Me.m_accVerifyForm.TreeView1.Nodes(treeViewIndex).Nodes.Add(New TreeNode("ChildCount Failure: Unexpected exception was caught.  Please investigate exception: " & ex.Message()))
            End Try

            If childCountPassed Then
                numberPassed += 1
            Else
                Me.m_accVerifyForm.TreeView1.Nodes(treeViewIndex).Nodes(ResultsType.ChildCount).ForeColor = System.Drawing.Color.Red
                numberFailed += 1
            End If

            ' begin defaultAction Verification
            errorLog = ""
            Dim defaultActionPassed As Boolean = False ' always fail by default to avoid false positives
            Try
                defaultActionPassed = msaaObject.VerifyDefaultAction(errorLog, typeofList)
                If defaultActionPassed Then
                    Me.m_accVerifyForm.TreeView1.Nodes(treeViewIndex).Nodes.Add(New TreeNode("DefaultAction Passed: " & errorLog))
                Else
                    Me.m_accVerifyForm.TreeView1.Nodes(treeViewIndex).Nodes.Add(New TreeNode("DefaultAction Failures: " & errorLog))
                End If
            Catch DefaultActionE As DefaultActionException
                Me.m_accVerifyForm.TreeView1.Nodes(treeViewIndex).Nodes.Add(New TreeNode("DefaultAction Failures: " & DefaultActionE.Message))
            Catch ex As Exception
                Me.m_accVerifyForm.TreeView1.Nodes(treeViewIndex).Nodes.Add(New TreeNode("DefaultAction Failures: Unexpected exception was caught.  Please investigate: " & ex.Message))
            End Try

            If defaultActionPassed Then
                numberPassed += 1
            Else
                Me.m_accVerifyForm.TreeView1.Nodes(treeViewIndex).Nodes(ResultsType.DefaultAction).ForeColor = System.Drawing.Color.Red
                numberFailed += 1
            End If

            errorLog = ""
            Dim descriptionPassed As Boolean = False ' always fail by default to avoid false positives
            Try
                descriptionPassed = msaaObject.VerifyDescription(errorLog, expectedDescription, typeofList)
                If descriptionPassed Then
                    Me.m_accVerifyForm.TreeView1.Nodes(treeViewIndex).Nodes.Add(New TreeNode("Description Passed: " & errorLog))
                Else
                    Me.m_accVerifyForm.TreeView1.Nodes(treeViewIndex).Nodes.Add(New TreeNode("Description Failures: " & errorLog))
                End If
            Catch DescriptionE As DescriptionException
                Me.m_accVerifyForm.TreeView1.Nodes(treeViewIndex).Nodes.Add(New TreeNode("Description Failures: " & DescriptionE.Message))
            Catch ex As Exception
                Me.m_accVerifyForm.TreeView1.Nodes(treeViewIndex).Nodes.Add(New TreeNode("Description Failures: Unexpected exception was caught.  Please investigate: " & ex.Message))
            End Try

            If descriptionPassed Then
                numberPassed += 1
            Else
                Me.m_accVerifyForm.TreeView1.Nodes(treeViewIndex).Nodes(ResultsType.Description).ForeColor = System.Drawing.Color.Red
                numberFailed += 1
            End If

            ' begin keyboardShortcut verifications
            errorLog = ""
            Dim keyboardShortcutPassed As Boolean = False ' always fail by default to avoid false positives
            Try
                keyboardShortcutPassed = msaaObject.VerifyKeyboardShortcut(errorLog, expectedKeyboardShortcut, typeofList)
                If keyboardShortcutPassed Then
                    Me.m_accVerifyForm.TreeView1.Nodes(treeViewIndex).Nodes.Add(New TreeNode("KeyboardShortcut Passed: " & errorLog))
                Else
                    Me.m_accVerifyForm.TreeView1.Nodes(treeViewIndex).Nodes.Add(New TreeNode("KeyboardShortcut Failures: " & errorLog))
                End If
            Catch KeyboardShortcutE As KeyboardShortcutException
                Me.m_accVerifyForm.TreeView1.Nodes(treeViewIndex).Nodes.Add(New TreeNode("KeyboardShortcut Failures: " & KeyboardShortcutE.Message))
            Catch ex As Exception
                Me.m_accVerifyForm.TreeView1.Nodes(treeViewIndex).Nodes.Add(New TreeNode("KeyboardShortcut Failures: Unexpected exception was caught.  Please investigate: " & ex.Message))
            End Try

            If keyboardShortcutPassed Then
                numberPassed += 1
            Else
                Me.m_accVerifyForm.TreeView1.Nodes(treeViewIndex).Nodes(ResultsType.KeyboardShortcut).ForeColor = System.Drawing.Color.Red
                numberFailed += 1
            End If

            ' begin Name Verification
            errorLog = ""
            Dim namePassed As Boolean = False ' always fail by default to avoid false positives
            Try
                namePassed = msaaObject.VerifyName(errorLog, expectedName, typeofList)
                If namePassed Then
                    Me.m_accVerifyForm.TreeView1.Nodes(treeViewIndex).Nodes.Add(New TreeNode("Name Passed: " & errorLog))
                Else
                    Me.m_accVerifyForm.TreeView1.Nodes(treeViewIndex).Nodes.Add(New TreeNode("Name Failures: " & errorLog))
                End If
            Catch NameE As NameException
                Me.m_accVerifyForm.TreeView1.Nodes(treeViewIndex).Nodes.Add(New TreeNode("Name Failures: " & NameE.Message))
            Catch ex As Exception
                Me.m_accVerifyForm.TreeView1.Nodes(treeViewIndex).Nodes.Add(New TreeNode("Name Failures: Unexpected exception was caught.  Please investigate:" & ex.Message))
            End Try

            If namePassed Then
                numberPassed += 1
            Else
                Me.m_accVerifyForm.TreeView1.Nodes(treeViewIndex).Nodes(ResultsType.Name).ForeColor = System.Drawing.Color.Red
                numberFailed += 1
            End If

            ' begin Parent verifications
            errorLog = ""
            Dim parentPassed As Boolean = False ' always fail by default to avoid false positives
            Try
                parentPassed = msaaObject.VerifyParent(errorLog, typeofList)
                If parentPassed Then
                    Me.m_accVerifyForm.TreeView1.Nodes(treeViewIndex).Nodes.Add(New TreeNode("Parent Passed: " & errorLog))
                Else
                    Me.m_accVerifyForm.TreeView1.Nodes(treeViewIndex).Nodes.Add(New TreeNode("Parent Failures: " & errorLog))
                End If
            Catch ParentE As ParentException
                Me.m_accVerifyForm.TreeView1.Nodes(treeViewIndex).Nodes.Add(New TreeNode("Parent Failures: " & ParentE.Message))
            Catch ex As Exception
                Me.m_accVerifyForm.TreeView1.Nodes(treeViewIndex).Nodes.Add(New TreeNode("Parent Failures: Unexpected exception was caught.  Please investigate: " & ex.Message))
            End Try

            If parentPassed Then
                numberPassed += 1
            Else
                Me.m_accVerifyForm.TreeView1.Nodes(treeViewIndex).Nodes(ResultsType.Parent).ForeColor = System.Drawing.Color.Red
                numberFailed += 1
            End If

            ' begin Role verifications
            errorLog = ""
            Dim rolePassed As Boolean = False ' always fail by default to avoid false positives
            Try
                rolePassed = msaaObject.VerifyRole(errorLog, typeofList)
                If rolePassed Then
                    Me.m_accVerifyForm.TreeView1.Nodes(treeViewIndex).Nodes.Add(New TreeNode("Role Passed: " & errorLog))
                Else
                    Me.m_accVerifyForm.TreeView1.Nodes(treeViewIndex).Nodes.Add(New TreeNode("Role Failures: " & errorLog))
                End If
            Catch RoleE As RoleException
                Me.m_accVerifyForm.TreeView1.Nodes(treeViewIndex).Nodes.Add(New TreeNode("Role Failures: " & RoleE.Message))
            Catch ex As Exception
                Me.m_accVerifyForm.TreeView1.Nodes(treeViewIndex).Nodes.Add(New TreeNode("Role Failures: Unexpected exception was caught.  Please investigate: " & ex.Message))
            End Try

            If rolePassed Then
                numberPassed += 1
            Else
                Me.m_accVerifyForm.TreeView1.Nodes(treeViewIndex).Nodes(ResultsType.Role).ForeColor = System.Drawing.Color.Red
                numberFailed += 1
            End If

            ' begin State verifications
            errorLog = ""
            Dim statePassed As Boolean = False ' always fail by default to avoid false positives
            Try
                statePassed = msaaObject.VerifyState(errorLog, typeofList)
                If statePassed Then
                    Me.m_accVerifyForm.TreeView1.Nodes(treeViewIndex).Nodes.Add(New TreeNode("State Passed: " & errorLog))
                Else
                    Me.m_accVerifyForm.TreeView1.Nodes(treeViewIndex).Nodes.Add(New TreeNode("State Failures: " & errorLog))
                End If
            Catch StateE As StateException
                Me.m_accVerifyForm.TreeView1.Nodes(treeViewIndex).Nodes.Add(New TreeNode("State Failures: " & StateE.Message))
            Catch ex As Exception
                Me.m_accVerifyForm.TreeView1.Nodes(treeViewIndex).Nodes.Add(New TreeNode("State Failures: Unexpected exception was caught.  Please investigate: " & ex.Message()))
            End Try

            If statePassed Then
                numberPassed += 1
            Else
                Me.m_accVerifyForm.TreeView1.Nodes(treeViewIndex).Nodes(ResultsType.State).ForeColor = System.Drawing.Color.Red
                numberFailed += 1
            End If

            ' begin verifications for value
            errorLog = ""
            Dim valuePassed As Boolean = False ' always fail by default to avoid false positives
            Try
                valuePassed = msaaObject.VerifyValue(errorLog, typeofList)
                If valuePassed Then
                    Me.m_accVerifyForm.TreeView1.Nodes(treeViewIndex).Nodes.Add(New TreeNode("Value Passed: " & errorLog))
                Else
                    Me.m_accVerifyForm.TreeView1.Nodes(treeViewIndex).Nodes.Add(New TreeNode("Value Failures: " & errorLog))
                End If
            Catch ValueE As ValueException
                Me.m_accVerifyForm.TreeView1.Nodes(treeViewIndex).Nodes.Add(New TreeNode("Value Failures: " & ValueE.Message))
            Catch ex As Exception
                Me.m_accVerifyForm.TreeView1.Nodes(treeViewIndex).Nodes.Add(New TreeNode("Value Failures: Unexpected exception was caught.  Please investigate:" & ex.Message))
            End Try

            If valuePassed Then
                numberPassed += 1
            Else
                Me.m_accVerifyForm.TreeView1.Nodes(treeViewIndex).Nodes(ResultsType.Value).ForeColor = System.Drawing.Color.Red
                numberFailed += 1
            End If

            ' update the root level node with numberPassed / numberFailed information
            Dim currentText As String = Me.m_accVerifyForm.TreeView1.Nodes(treeViewIndex).Text
            Me.m_accVerifyForm.TreeView1.Nodes(treeViewIndex).Text = currentText & " (Results: " & numberPassed & " of " & NumberOfMsaaVerifications & " Passed)"

            ' updated root color
            If numberFailed > 0 Then
                Me.m_accVerifyForm.TreeView1.Nodes(treeViewIndex).ForeColor = System.Drawing.Color.Red
            End If

            ' update overall status
            Me.m_totalNumberPassed += numberPassed
            Me.m_totalNumberFailed += numberFailed

            Me.UpdateNumericalResults()
        End Sub

        Private Sub UpdateNumericalResults()
            Me.m_accVerifyForm.TextBoxPassed.Text = Me.m_totalNumberPassed.ToString
            Me.m_accVerifyForm.TextBoxFailed.Text = Me.m_totalNumberFailed.ToString
        End Sub

        Private Sub ResetNumericalResults()
            Me.m_totalNumberPassed = 0
            Me.m_totalNumberFailed = 0
        End Sub
#End Region

    End Class
End Namespace