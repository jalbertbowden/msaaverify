Imports System.Text
Imports System.Runtime.InteropServices

Namespace MsaaVerify
    Public MustInherit Class NativeMethods
        <StructLayout(LayoutKind.Sequential)> _
        Public Structure LVITEM
            Dim mask As Integer
            Dim iItem As Integer
            Dim iSubItem As Integer
            Dim state As Integer
            Dim stateMask As Integer
            Dim pszText As IntPtr
            Dim cchTextMax As Integer
            Dim iImage As Integer
            Dim lParam As IntPtr ' LPARAMInteger
            Dim iIndent As Integer
        End Structure

        <StructLayout(LayoutKind.Sequential)> _
        Public Structure HDITEM
            Dim mask As Integer
            Dim cxy As Integer
            Dim pszText As IntPtr
            Dim hbm As IntPtr
            Dim cchTextMax As Integer
            Dim fmt As Integer
            Dim lParam As IntPtr
        End Structure

#Region "Constants"

        Public Const NumChars As Integer = 32512
        Public Const NumBytes As Integer = NumChars * 2
        Public Const WM_USER As Integer = &H400
        Public Const WM_GETTEXT As Integer = &HD

        ' combo box constants
        Public Const CB_GETCOUNT As Integer = &H146
        Public Const CB_ERR As Integer = (-1)
        Public Const CB_GETLBTEXT As Integer = &H148
        Public Const CB_GETCURSEL As Integer = &H147

        ' header constants
        Public Const HDM_FIRST As Long = &H1200&
        Public Const HDM_GETITEMCOUNT As Long = (HDM_FIRST + 0)
        Public Const HDI_TEXT As Long = &H2
        Public Const HDM_GETITEM As Long = (HDM_FIRST + 11)

        ' status bar constants
        Public Const SB_GETPARTS As Integer = (WM_USER + 6)
        Public Const SB_GETTEXT As Integer = (WM_USER + 13)
        Public Const SB_GETTEXTLENGTH As Integer = (WM_USER + 12)
        Public Const SBT_OWNERDRAW As Integer = &H1000

        ' list box constants
        Public Const LB_GETCOUNT As Integer = &H18B
        Public Const LB_ERR As Integer = (-1)
        Public Const LB_GETTEXT As Integer = &H189

        'ListView constants
        Public Const LVM_FIRST As Integer = &H1000
        Public Const LVM_GETITEM As Integer = (LVM_FIRST + 5)
        Public Const LVM_GETITEMCOUNT As Integer = (LVM_FIRST + 4)
        Public Const LVM_GETHEADER As Integer = (LVM_FIRST + 31)
        Public Const LVIF_TEXT As Integer = &H1
        Public Const LVM_GETITEMTEXT As Integer = (LVM_FIRST + 115)

        ' kernel constants
        Public Const PROCESS_VM_OPERATION As Short = &H8S
        Public Const PROCESS_VM_READ As Short = &H10S
        Public Const PROCESS_VM_WRITE As Short = &H20S
        Public Const MEM_COMMIT As Short = &H1000S
        Public Const MEM_RESERVE As Short = &H2000S
        Public Const MEM_RELEASE As Integer = &H8000&
        Public Const PAGE_READWRITE As Integer = &H4

        ' COM Results Constant from winerror.h - needed for MsaaVerify for certain WinControls
        Public Const DISP_E_MEMBERNOTFOUND As Integer = &H80020003
#End Region

#Region "API Calls"
        'kernel32
        Public Declare Function OpenProcess Lib "kernel32" Alias "OpenProcess" (ByVal dwDesiredAccess As Integer, ByVal bInheritHandle As Integer, ByVal dwProcessId As Integer) As IntPtr
        Public Declare Function VirtualAllocEx Lib "kernel32" Alias "VirtualAllocEx" (ByVal hProcess As IntPtr, ByVal lpAddress As IntPtr, ByVal dwSize As IntPtr, ByVal flAllocationType As Integer, ByVal flProtect As Integer) As IntPtr
        Public Declare Function WriteProcessMemory Lib "kernel32" Alias "WriteProcessMemory" (ByVal hProcess As IntPtr, ByVal lpBaseAddress As IntPtr, ByRef lpBuffer As Byte, ByVal nSize As IntPtr, ByRef lpNumberOfBytesWritten As IntPtr) As Integer
        Public Declare Function ReadProcessMemory Lib "kernel32" Alias "ReadProcessMemory" (ByVal hProcess As IntPtr, ByVal lpBaseAddress As IntPtr, ByRef lpBuffer As Byte, ByVal nSize As IntPtr, ByRef lpNumberOfBytesWritten As IntPtr) As Integer
        Public Declare Function VirtualFreeEx Lib "kernel32" Alias "VirtualFreeEx" (ByVal hProcess As IntPtr, ByVal lpAddress As IntPtr, ByVal dwSize As IntPtr, ByVal dwFreeType As Integer) As Integer
        Public Declare Function CloseHandle Lib "kernel32" Alias "CloseHandle" (ByVal hObject As IntPtr) As Integer
        Public Declare Function GetWindowThreadProcessId Lib "user32" Alias "GetWindowThreadProcessId" (ByVal HWnd As IntPtr, ByRef lpdwProcessId As Integer) As Integer
        Public Declare Function WriteProcessMemoryLV Lib "kernel32" Alias "WriteProcessMemory" (ByVal hProcess As IntPtr, ByVal lpBaseAddress As IntPtr, ByRef lpBuffer As NativeMethods.LVITEM, ByVal nSize As IntPtr, ByRef lpNumberOfBytesWritten As IntPtr) As Integer
        Public Declare Function ReadProcessMemoryLV Lib "kernel32" Alias "ReadProcessMemory" (ByVal hProcess As IntPtr, ByVal lpBaseAddress As IntPtr, ByRef lpBuffer As NativeMethods.LVITEM, ByVal nSize As IntPtr, ByRef lpNumberOfBytesWritten As IntPtr) As Integer
        Public Declare Function WriteProcessMemoryHD Lib "kernel32" Alias "WriteProcessMemory" (ByVal hProcess As IntPtr, ByVal lpBaseAddress As IntPtr, ByRef lpBuffer As NativeMethods.HDITEM, ByVal nSize As IntPtr, ByRef lpNumberOfBytesWritten As IntPtr) As Integer
        Public Declare Function ReadProcessMemoryHD Lib "kernel32" Alias "ReadProcessMemory" (ByVal hProcess As IntPtr, ByVal lpBaseAddress As IntPtr, ByRef lpBuffer As NativeMethods.HDITEM, ByVal nSize As IntPtr, ByRef lpNumberOfBytesWritten As IntPtr) As Integer
        Public Declare Function GetLastError Lib "kernel32" Alias "GetLastError" () As Integer

        ' user32
        Public Declare Unicode Function GetWindowText Lib "user32" Alias "GetWindowTextW" (ByVal HWnd As IntPtr, ByVal byteArray As Char(), ByVal cch As Integer) As Integer
        Public Declare Ansi Function GetWindowTextA Lib "user32" Alias "GetWindowTextA" (ByVal HWnd As IntPtr, ByVal byteArray As Byte(), ByVal cch As Integer) As Integer
        Public Declare Function GetWindowTextLength Lib "user32" Alias "GetWindowTextLengthW" (ByVal HWnd As IntPtr) As Integer
        Public Declare Function GetWindowTextLengthA Lib "user32" Alias "GetWindowTextLengthA" (ByVal HWnd As IntPtr) As Integer
        Public Declare Function GetDlgCtrlID Lib "user32" Alias "GetDlgCtrlID" (ByVal HWnd As IntPtr) As Integer
        Public Declare Function SendMessage Lib "user32" Alias "SendMessageA" (ByVal HWnd As IntPtr, ByVal wMsg As Integer, ByVal wParam As IntPtr, ByVal lParam As IntPtr) As IntPtr
        Public Declare Function SendMessageByStringBuilderA Lib "user32" Alias "SendMessageA" (ByVal HWnd As IntPtr, ByVal wMsg As Integer, ByVal wParam As IntPtr, ByVal lParam As StringBuilder) As IntPtr
        Public Declare Unicode Function SendMessageByStringBuilder Lib "user32" Alias "SendMessageW" (ByVal HWnd As IntPtr, ByVal wMsg As Integer, ByVal wParam As IntPtr, ByVal lParam As StringBuilder) As IntPtr
        Public Declare Function IsWindow Lib "user32" Alias "IsWindow" (ByVal HWnd As IntPtr) As Integer

        ' needed for Spy tools
        Public Declare Function WindowFromPoint Lib "user32" Alias "WindowFromPoint" (ByVal X As Integer, ByVal Y As Integer) As Integer
        Public Declare Function GetAncestor Lib "user32" Alias "GetAncestor" (ByVal hwnd As Integer, ByVal gaFlags As Integer) As Integer
        Public Declare Function GetWindowText Lib "user32" Alias "GetWindowTextA" (ByVal HWnd As Integer, ByVal lpString As System.Text.StringBuilder, ByVal cch As Integer) As Integer
        Public Declare Function GetClassName Lib "user32" Alias "GetClassNameA" (ByVal HWnd As IntPtr, ByVal lpClassName As IntPtr, ByVal nMaxCount As Integer) As Integer

        ' GDI32 - needed to draw the little box around the AA object found while search like AccExplorer
        Public Declare Function BitBlt Lib "Gdi32" Alias "BitBlt" (ByVal hdcDest As IntPtr, ByVal nXDest As Integer, ByVal nYDest As Integer, ByVal nWidth As Integer, ByVal nHeight As Integer, ByVal hdcSrc As IntPtr, ByVal nXSrc As Integer, ByVal nYSrc As Integer, ByVal dwRop As Integer) As Boolean
        Public Declare Function CreateCompatibleDC Lib "Gdi32" Alias "CreateCompatibleDC" (ByVal hDC As IntPtr) As IntPtr
        Public Declare Function CreateCompatibleBitmap Lib "Gdi32" Alias "CreateCompatibleBitmap" (ByVal hDC As IntPtr, ByVal Width As Integer, ByVal Height As Integer) As IntPtr
        Public Declare Function SelectObject Lib "Gdi32" Alias "SelectObject" (ByVal hDC As IntPtr, ByVal hgdiobj As IntPtr) As IntPtr
        Public Declare Function DeleteDC Lib "gdi32.dll" Alias "DeleteDC" (ByVal hdc As IntPtr) As Boolean
        Public Declare Function DeleteObject Lib "gdi32.dll" Alias "DeleteObject" (ByVal handle As IntPtr) As Boolean
        Public Declare Function GetDC Lib "user32" Alias "GetDC" (ByVal hWnd As Integer) As IntPtr

        ' oleacc.dll
        Public Declare Function AccessibleChildren Lib "oleacc" Alias "AccessibleChildren" (ByVal paccContainer As Accessibility.IAccessible, ByVal iChildStart As Integer, ByVal cChildren As Integer, <MarshalAs(UnmanagedType.LPArray, SizeParamIndex:=2), InAttribute(), Out()> ByVal rgvarChildren() As Object, ByRef pcObtained As Integer) As Integer
        Public Declare Function AccessibleObjectFromPoint Lib "oleacc" Alias "AccessibleObjectFromPoint" (ByVal lx As Integer, ByVal ly As Integer, ByRef ppoleAcc As Accessibility.IAccessible, ByRef pvarElement As Object) As Integer
        Public Declare Function AccessibleObjectFromWindow Lib "oleacc" Alias "AccessibleObjectFromWindow" (ByVal hwnd As IntPtr, ByVal dwId As Integer, ByRef riid As Guid, ByRef ppvObject As Accessibility.IAccessible) As Integer
        Public Declare Function GetStateText Lib "oleacc" Alias "GetStateTextA" (ByVal dwStateBit As Integer, ByVal szState As StringBuilder, ByVal cchStateBitMax As Short) As Integer
        Public Declare Function WindowFromAccessibleObject Lib "oleacc" Alias "WindowFromAccessibleObject" (ByVal paccIdentity As Accessibility.IAccessible, ByRef hwnd As IntPtr) As Integer
        Public Declare Function GetRoleText Lib "oleacc" Alias "GetRoleTextA" (ByVal dwRole As Integer, ByVal szRole As StringBuilder, ByVal cchRoleMax As Short) As Integer
#End Region

    End Class
End Namespace
