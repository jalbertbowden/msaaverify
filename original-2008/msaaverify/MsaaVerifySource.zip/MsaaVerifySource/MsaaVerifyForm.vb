Imports Accessibility

Namespace MsaaVerify

    Public Class MsaaVerifyForm
        Inherits System.Windows.Forms.Form

#Region "Constants"
        'GetAncestor Constants
        Private Const GaRoot As Integer = 2
        ' needed for GDI drawing
        Const SrcCopy As Integer = &HCC0020
        ' needed for GDI drawing
        Const PenWidth As Integer = 4
        ' status bar messages
        Const StatusBarMessageSearching As String = "Searching..."
#End Region

#Region "Private Variables"
        ' class for msaa searches and such
        Private m_ops As Operations
        ' this list contains the found MSAA objects from the search
        Private m_msaaArraList As ArrayList
        ' variable for spy tool methods to know whether or not the mouse is down
        Private m_blnMouseDown As Boolean = False
        ' variable to show appropriate context menu / menu items
        Private m_hasVerifiedThisSession As Boolean = False
        ' the found MSAA object(s) from the spy tool 
        Private m_foundMsaaObject As AccessibleObject = Nothing
        ' found hwnd from the spy tool 
        Private m_foundHwnd As Integer = 0
        ' private newline
        Dim NewLine As String = System.Environment.NewLine()

        ' needed for GDI drawing
        Private m_hDCScreen As IntPtr
        Private m_hDCScreenCompatible As IntPtr
        Private m_hDCOld As IntPtr
        Private m_hScreenCompatibleBmp As IntPtr
#End Region

#Region "Windows Form Designer generated code "

        Public Sub New()
            MyBase.New()

            'This call is required by the Windows Form Designer.
            InitializeComponent()

            ' create instance of operations class
            m_ops = New Operations(Me)

            ' this array contains all the found MSAA objects (those that appear in the tree view level 0)
            m_msaaArraList = New ArrayList

            If Me.IsWin9x Then
                MsgBox("MsaaVerify is not supported on Win9x platforms.  Use at own risk.", MsgBoxStyle.Exclamation, "Warning!")
            End If
        End Sub

        'Form overrides dispose to clean up the component list.
        Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
            If disposing Then
                If Not (components Is Nothing) Then
                    components.Dispose()
                End If
            End If
            MyBase.Dispose(disposing)
        End Sub

        'Required by the Windows Form Designer
        Private components As System.ComponentModel.IContainer

        'NOTE: The following procedure is required by the Windows Form Designer
        'It can be modified using the Windows Form Designer.  
        'Do not modify it using the code editor.
        Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
        Friend WithEvents Label4 As System.Windows.Forms.Label
        Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
        Friend WithEvents Label5 As System.Windows.Forms.Label
        Friend WithEvents TextBox3 As System.Windows.Forms.TextBox
        Friend WithEvents Label6 As System.Windows.Forms.Label
        Friend WithEvents Label7 As System.Windows.Forms.Label
        Friend WithEvents TextBoxPassed As System.Windows.Forms.TextBox
        Friend WithEvents TextBoxFailed As System.Windows.Forms.TextBox
        Friend WithEvents StatusBar1 As System.Windows.Forms.StatusBar
        Friend WithEvents Label2 As System.Windows.Forms.Label
        Friend WithEvents TreeView1 As System.Windows.Forms.TreeView
        Friend WithEvents PictureBox2 As System.Windows.Forms.PictureBox
        Friend WithEvents VerifyButton As System.Windows.Forms.Button
        Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
        Friend WithEvents Label1 As System.Windows.Forms.Label
        Friend WithEvents CrosshairsRadioButton As System.Windows.Forms.RadioButton
        Friend WithEvents HwndRadioButton As System.Windows.Forms.RadioButton
        Friend WithEvents CaptureButton As System.Windows.Forms.Button
        Friend WithEvents HwndTextBox As System.Windows.Forms.TextBox
        Friend WithEvents ResetFormButton As System.Windows.Forms.Button
        Friend WithEvents MenuItemVerifyNow As System.Windows.Forms.MenuItem
        Friend WithEvents MainMenu1 As System.Windows.Forms.MainMenu
        Friend WithEvents MenuItemVerify As System.Windows.Forms.MenuItem
        Friend WithEvents MenuItemHelp As System.Windows.Forms.MenuItem
        Friend WithEvents MenuItemAbout As System.Windows.Forms.MenuItem
        Friend WithEvents MenuItemVerifyMsaa As System.Windows.Forms.MenuItem
        Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
        Friend WithEvents Label3 As System.Windows.Forms.Label
        Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
        Friend WithEvents MenuItemHelpVerifications As System.Windows.Forms.MenuItem

        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
            Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(MsaaVerifyForm))
            Me.PictureBox1 = New System.Windows.Forms.PictureBox
            Me.Label4 = New System.Windows.Forms.Label
            Me.TextBox2 = New System.Windows.Forms.TextBox
            Me.Label5 = New System.Windows.Forms.Label
            Me.TextBox3 = New System.Windows.Forms.TextBox
            Me.Label6 = New System.Windows.Forms.Label
            Me.Label7 = New System.Windows.Forms.Label
            Me.TextBoxPassed = New System.Windows.Forms.TextBox
            Me.TextBoxFailed = New System.Windows.Forms.TextBox
            Me.StatusBar1 = New System.Windows.Forms.StatusBar
            Me.VerifyButton = New System.Windows.Forms.Button
            Me.Label2 = New System.Windows.Forms.Label
            Me.TreeView1 = New System.Windows.Forms.TreeView
            Me.PictureBox2 = New System.Windows.Forms.PictureBox
            Me.CrosshairsRadioButton = New System.Windows.Forms.RadioButton
            Me.HwndRadioButton = New System.Windows.Forms.RadioButton
            Me.GroupBox1 = New System.Windows.Forms.GroupBox
            Me.CaptureButton = New System.Windows.Forms.Button
            Me.HwndTextBox = New System.Windows.Forms.TextBox
            Me.Label1 = New System.Windows.Forms.Label
            Me.ResetFormButton = New System.Windows.Forms.Button
            Me.GroupBox2 = New System.Windows.Forms.GroupBox
            Me.Label3 = New System.Windows.Forms.Label
            Me.TextBox1 = New System.Windows.Forms.TextBox
            Me.MainMenu1 = New System.Windows.Forms.MainMenu
            Me.MenuItemVerify = New System.Windows.Forms.MenuItem
            Me.MenuItemVerifyMsaa = New System.Windows.Forms.MenuItem
            Me.MenuItemHelp = New System.Windows.Forms.MenuItem
            Me.MenuItemHelpVerifications = New System.Windows.Forms.MenuItem
            Me.MenuItemAbout = New System.Windows.Forms.MenuItem
            Me.GroupBox1.SuspendLayout()
            Me.GroupBox2.SuspendLayout()
            Me.SuspendLayout()
            '
            'PictureBox1
            '
            Me.PictureBox1.AccessibleDescription = "drag cross hairs over an image to capture its hwnd"
            Me.PictureBox1.AccessibleName = "Crosshair Image"
            Me.PictureBox1.BackColor = System.Drawing.SystemColors.Control
            Me.PictureBox1.Location = New System.Drawing.Point(208, 24)
            Me.PictureBox1.Name = "PictureBox1"
            Me.PictureBox1.Size = New System.Drawing.Size(24, 24)
            Me.PictureBox1.TabIndex = 2
            Me.PictureBox1.TabStop = False
            '
            'Label4
            '
            Me.Label4.AccessibleName = "AA Name:"
            Me.Label4.Location = New System.Drawing.Point(8, 23)
            Me.Label4.Name = "Label4"
            Me.Label4.Size = New System.Drawing.Size(96, 23)
            Me.Label4.TabIndex = 6
            Me.Label4.Text = "Accessible &Name:"
            '
            'TextBox2
            '
            Me.TextBox2.AccessibleName = "AA Name:"
            Me.TextBox2.Location = New System.Drawing.Point(112, 20)
            Me.TextBox2.Name = "TextBox2"
            Me.TextBox2.ReadOnly = True
            Me.TextBox2.Size = New System.Drawing.Size(272, 20)
            Me.TextBox2.TabIndex = 7
            Me.TextBox2.Text = ""
            '
            'Label5
            '
            Me.Label5.AccessibleName = "Class Name:"
            Me.Label5.Location = New System.Drawing.Point(8, 72)
            Me.Label5.Name = "Label5"
            Me.Label5.Size = New System.Drawing.Size(72, 23)
            Me.Label5.TabIndex = 8
            Me.Label5.Text = "C&lass Name:"
            '
            'TextBox3
            '
            Me.TextBox3.AccessibleName = "Class Name:"
            Me.TextBox3.Location = New System.Drawing.Point(112, 72)
            Me.TextBox3.Name = "TextBox3"
            Me.TextBox3.ReadOnly = True
            Me.TextBox3.Size = New System.Drawing.Size(272, 20)
            Me.TextBox3.TabIndex = 9
            Me.TextBox3.Text = ""
            '
            'Label6
            '
            Me.Label6.AccessibleName = "Passed:"
            Me.Label6.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
            Me.Label6.ForeColor = System.Drawing.Color.Blue
            Me.Label6.Location = New System.Drawing.Point(215, 481)
            Me.Label6.Name = "Label6"
            Me.Label6.Size = New System.Drawing.Size(48, 16)
            Me.Label6.TabIndex = 15
            Me.Label6.Text = "&Passed"
            '
            'Label7
            '
            Me.Label7.AccessibleName = "Failed:"
            Me.Label7.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
            Me.Label7.ForeColor = System.Drawing.Color.Red
            Me.Label7.Location = New System.Drawing.Point(310, 481)
            Me.Label7.Name = "Label7"
            Me.Label7.Size = New System.Drawing.Size(40, 16)
            Me.Label7.TabIndex = 17
            Me.Label7.Text = "Faile&d"
            '
            'TextBoxPassed
            '
            Me.TextBoxPassed.AccessibleName = "Passed:"
            Me.TextBoxPassed.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
            Me.TextBoxPassed.Location = New System.Drawing.Point(263, 481)
            Me.TextBoxPassed.Name = "TextBoxPassed"
            Me.TextBoxPassed.ReadOnly = True
            Me.TextBoxPassed.Size = New System.Drawing.Size(40, 20)
            Me.TextBoxPassed.TabIndex = 16
            Me.TextBoxPassed.Text = ""
            '
            'TextBoxFailed
            '
            Me.TextBoxFailed.AccessibleName = "Failed:"
            Me.TextBoxFailed.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
            Me.TextBoxFailed.Location = New System.Drawing.Point(351, 481)
            Me.TextBoxFailed.Name = "TextBoxFailed"
            Me.TextBoxFailed.ReadOnly = True
            Me.TextBoxFailed.Size = New System.Drawing.Size(40, 20)
            Me.TextBoxFailed.TabIndex = 18
            Me.TextBoxFailed.Text = ""
            '
            'StatusBar1
            '
            Me.StatusBar1.AccessibleName = "AccVerify Status Bar"
            Me.StatusBar1.Location = New System.Drawing.Point(0, 503)
            Me.StatusBar1.Name = "StatusBar1"
            Me.StatusBar1.Size = New System.Drawing.Size(452, 22)
            Me.StatusBar1.TabIndex = 20
            Me.StatusBar1.Text = "Ready"
            '
            'VerifyButton
            '
            Me.VerifyButton.AccessibleName = "Verify MSAA"
            Me.VerifyButton.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
            Me.VerifyButton.Enabled = False
            Me.VerifyButton.Location = New System.Drawing.Point(8, 479)
            Me.VerifyButton.Name = "VerifyButton"
            Me.VerifyButton.Size = New System.Drawing.Size(96, 23)
            Me.VerifyButton.TabIndex = 11
            Me.VerifyButton.Text = "&Verify MSAA"
            '
            'Label2
            '
            Me.Label2.AccessibleName = "Active Accessibility Objects Found:"
            Me.Label2.Location = New System.Drawing.Point(8, 227)
            Me.Label2.Name = "Label2"
            Me.Label2.Size = New System.Drawing.Size(184, 16)
            Me.Label2.TabIndex = 13
            Me.Label2.Text = "Active Accessibility Objects &Found:"
            '
            'TreeView1
            '
            Me.TreeView1.AccessibleName = "Active Accessibility Objects Found:"
            Me.TreeView1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                        Or System.Windows.Forms.AnchorStyles.Left) _
                        Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
            Me.TreeView1.ImageIndex = -1
            Me.TreeView1.Location = New System.Drawing.Point(8, 243)
            Me.TreeView1.Name = "TreeView1"
            Me.TreeView1.SelectedImageIndex = -1
            Me.TreeView1.Size = New System.Drawing.Size(402, 233)
            Me.TreeView1.TabIndex = 14
            '
            'PictureBox2
            '
            Me.PictureBox2.AccessibleDescription = "Frame for holding the image"
            Me.PictureBox2.AccessibleName = "Crosshair Image Frame"
            Me.PictureBox2.AccessibleRole = System.Windows.Forms.AccessibleRole.Graphic
            Me.PictureBox2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
            Me.PictureBox2.Location = New System.Drawing.Point(200, 16)
            Me.PictureBox2.Name = "PictureBox2"
            Me.PictureBox2.Size = New System.Drawing.Size(40, 40)
            Me.PictureBox2.TabIndex = 26
            Me.PictureBox2.TabStop = False
            '
            'CrosshairsRadioButton
            '
            Me.CrosshairsRadioButton.AccessibleName = "Using the crosshairs"
            Me.CrosshairsRadioButton.Checked = True
            Me.CrosshairsRadioButton.Location = New System.Drawing.Point(16, 24)
            Me.CrosshairsRadioButton.Name = "CrosshairsRadioButton"
            Me.CrosshairsRadioButton.Size = New System.Drawing.Size(160, 24)
            Me.CrosshairsRadioButton.TabIndex = 1
            Me.CrosshairsRadioButton.TabStop = True
            Me.CrosshairsRadioButton.Text = "&Using the crosshairs"
            '
            'HwndRadioButton
            '
            Me.HwndRadioButton.AccessibleName = "Entering the HWND"
            Me.HwndRadioButton.Location = New System.Drawing.Point(16, 48)
            Me.HwndRadioButton.Name = "HwndRadioButton"
            Me.HwndRadioButton.Size = New System.Drawing.Size(160, 24)
            Me.HwndRadioButton.TabIndex = 2
            Me.HwndRadioButton.Text = "&Entering the HWND"
            '
            'GroupBox1
            '
            Me.GroupBox1.AccessibleName = "Search"
            Me.GroupBox1.Controls.Add(Me.PictureBox1)
            Me.GroupBox1.Controls.Add(Me.CaptureButton)
            Me.GroupBox1.Controls.Add(Me.PictureBox2)
            Me.GroupBox1.Controls.Add(Me.HwndTextBox)
            Me.GroupBox1.Controls.Add(Me.Label1)
            Me.GroupBox1.Location = New System.Drawing.Point(8, 8)
            Me.GroupBox1.Name = "GroupBox1"
            Me.GroupBox1.Size = New System.Drawing.Size(400, 104)
            Me.GroupBox1.TabIndex = 0
            Me.GroupBox1.TabStop = False
            Me.GroupBox1.Text = "Search"
            '
            'CaptureButton
            '
            Me.CaptureButton.AccessibleName = "Capture"
            Me.CaptureButton.Location = New System.Drawing.Point(192, 72)
            Me.CaptureButton.Name = "CaptureButton"
            Me.CaptureButton.Size = New System.Drawing.Size(56, 23)
            Me.CaptureButton.TabIndex = 5
            Me.CaptureButton.Text = "&Capture"
            '
            'HwndTextBox
            '
            Me.HwndTextBox.AccessibleName = "HWND:"
            Me.HwndTextBox.Location = New System.Drawing.Point(56, 73)
            Me.HwndTextBox.Name = "HwndTextBox"
            Me.HwndTextBox.ReadOnly = True
            Me.HwndTextBox.Size = New System.Drawing.Size(120, 20)
            Me.HwndTextBox.TabIndex = 4
            Me.HwndTextBox.Text = ""
            '
            'Label1
            '
            Me.Label1.AccessibleName = "HWND:"
            Me.Label1.Location = New System.Drawing.Point(8, 75)
            Me.Label1.Name = "Label1"
            Me.Label1.Size = New System.Drawing.Size(48, 16)
            Me.Label1.TabIndex = 3
            Me.Label1.Text = "&HWND:"
            '
            'ResetFormButton
            '
            Me.ResetFormButton.AccessibleName = "Clear Objects:"
            Me.ResetFormButton.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
            Me.ResetFormButton.Location = New System.Drawing.Point(111, 479)
            Me.ResetFormButton.Name = "ResetFormButton"
            Me.ResetFormButton.Size = New System.Drawing.Size(96, 23)
            Me.ResetFormButton.TabIndex = 19
            Me.ResetFormButton.Text = "Cl&ear Objects"
            '
            'GroupBox2
            '
            Me.GroupBox2.Controls.Add(Me.Label3)
            Me.GroupBox2.Controls.Add(Me.TextBox1)
            Me.GroupBox2.Controls.Add(Me.Label4)
            Me.GroupBox2.Controls.Add(Me.Label5)
            Me.GroupBox2.Controls.Add(Me.TextBox2)
            Me.GroupBox2.Controls.Add(Me.TextBox3)
            Me.GroupBox2.Location = New System.Drawing.Point(8, 119)
            Me.GroupBox2.Name = "GroupBox2"
            Me.GroupBox2.Size = New System.Drawing.Size(400, 97)
            Me.GroupBox2.TabIndex = 21
            Me.GroupBox2.TabStop = False
            Me.GroupBox2.Text = "Captured Control"
            '
            'Label3
            '
            Me.Label3.Location = New System.Drawing.Point(8, 48)
            Me.Label3.Name = "Label3"
            Me.Label3.Size = New System.Drawing.Size(88, 23)
            Me.Label3.TabIndex = 11
            Me.Label3.Text = "Accessible &Role:"
            '
            'TextBox1
            '
            Me.TextBox1.Location = New System.Drawing.Point(112, 48)
            Me.TextBox1.Name = "TextBox1"
            Me.TextBox1.ReadOnly = True
            Me.TextBox1.Size = New System.Drawing.Size(272, 20)
            Me.TextBox1.TabIndex = 10
            Me.TextBox1.Text = ""
            '
            'MainMenu1
            '
            Me.MainMenu1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.MenuItemVerify, Me.MenuItemHelp})
            '
            'MenuItemVerify
            '
            Me.MenuItemVerify.Index = 0
            Me.MenuItemVerify.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.MenuItemVerifyMsaa})
            Me.MenuItemVerify.Text = "Verify"
            '
            'MenuItemVerifyMsaa
            '
            Me.MenuItemVerifyMsaa.Index = 0
            Me.MenuItemVerifyMsaa.Text = "Verify MSAA"
            '
            'MenuItemHelp
            '
            Me.MenuItemHelp.Index = 1
            Me.MenuItemHelp.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.MenuItemHelpVerifications, Me.MenuItemAbout})
            Me.MenuItemHelp.Text = "Help"
            '
            'MenuItemHelpVerifications
            '
            Me.MenuItemHelpVerifications.Index = 0
            Me.MenuItemHelpVerifications.Text = "MSAA Verifications"
            '
            'MenuItemAbout
            '
            Me.MenuItemAbout.Index = 1
            Me.MenuItemAbout.Text = "About"
            '
            'MsaaVerifyForm
            '
            Me.AccessibleName = "MsaaVerifyForm"
            Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
            Me.AutoScroll = True
            Me.ClientSize = New System.Drawing.Size(452, 525)
            Me.Controls.Add(Me.ResetFormButton)
            Me.Controls.Add(Me.HwndRadioButton)
            Me.Controls.Add(Me.CrosshairsRadioButton)
            Me.Controls.Add(Me.TreeView1)
            Me.Controls.Add(Me.Label2)
            Me.Controls.Add(Me.VerifyButton)
            Me.Controls.Add(Me.StatusBar1)
            Me.Controls.Add(Me.TextBoxFailed)
            Me.Controls.Add(Me.TextBoxPassed)
            Me.Controls.Add(Me.Label7)
            Me.Controls.Add(Me.Label6)
            Me.Controls.Add(Me.GroupBox1)
            Me.Controls.Add(Me.GroupBox2)
            Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
            Me.Menu = Me.MainMenu1
            Me.Name = "MsaaVerifyForm"
            Me.Text = "MsaaVerify"
            Me.GroupBox1.ResumeLayout(False)
            Me.GroupBox2.ResumeLayout(False)
            Me.ResumeLayout(False)

        End Sub

#End Region

#Region "Spy Tool Methods"

        Private Sub PictureBox1_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles PictureBox1.MouseDown
            PictureBox1.Invalidate()
            ResetForm()
            m_blnMouseDown = True
            Me.Cursor = New Cursor("crosshairs.cur")
            Me.StatusBar1.Text = StatusBarMessageSearching
        End Sub

        Private Sub PictureBox1_MouseMove(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles PictureBox1.MouseMove
            If m_blnMouseDown Then
                PictureBox1.Invalidate()
            End If

            ClearRect()

            Try
                HandleMouse()
            Catch ex As MsaaVerify.CannotCreateAccessibleObjectException
                Me.StatusBar1.Text = ex.Message
            End Try
        End Sub

        Private Sub HandleMouse()
            If m_blnMouseDown Then
                ' we are searching like accExplorer
                Dim x As Integer = CType(Cursor.Position.X, Integer)
                Dim y As Integer = CType(Cursor.Position.Y, Integer)

                ' create the accessible object by point
                Try
                    m_foundMsaaObject = New AccessibleObject(x, y)
                Catch ex As Exception
                    Throw New MsaaVerify.CannotCreateAccessibleObjectException("Failed to create accessible object by point", ex)
                End Try

                ' show the AA Name on the form (sanity check)
                Try
                    Me.TextBox2.Text = m_foundMsaaObject.Name
                Catch e As Exception
                    Me.TextBox2.Text = ""
                End Try

                ' show the class name (sanity check)
                Try
                    Me.TextBox3.Text = m_foundMsaaObject.ClassName
                Catch ex As Exception
                    Me.TextBox3.Text = "Unknown Classname"  ' null str in this text box is fine
                End Try

                ' show the role type (sanity check)
                Try
                    Me.TextBox1.Text = m_foundMsaaObject.RoleText
                Catch ex As Exception
                    Me.TextBox1.Text = "Unknown Role"  ' null str in this text box is fine
                End Try

                ' show the HWND
                Try
                    Me.HwndTextBox.Text = m_foundMsaaObject.Hwnd.ToString
                Catch ex As Exception
                    Me.HwndTextBox.Text = "Unknown Hwnd"
                End Try

                ' draw the rectangle around the object
                DrawRect(m_foundMsaaObject.X, m_foundMsaaObject.Y, m_foundMsaaObject.Width, m_foundMsaaObject.Height)
            End If
        End Sub

        Private Sub PictureBox1_MouseUp(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles PictureBox1.MouseUp
            m_blnMouseDown = False
            Me.Cursor = Cursors.WaitCursor

            PictureBox1.Refresh()
            ClearRect()

            PopulateTreeViewWithControls()
            Me.Cursor = Cursors.Default
        End Sub

        Private Sub PopulateTreeViewWithControls()
            ' Clear the arra list if we've done previous searches and find the MSAA objects
            m_msaaArraList.Clear()

            ' check for valid aa object.  Fix Bug: Clicking on the crosshairs throws exception
            If Me.m_foundMsaaObject Is Nothing Then
                Me.StatusBar1.Text = "Failed to find valid MSAA object"
            Else
                ' populate arra list with the msaa objects found
                m_msaaArraList = m_ops.GenerateMsaaInfo(m_foundMsaaObject, m_foundHwnd)

                ' check for no AA objects
                If m_msaaArraList.Count = 0 Then
                    Me.StatusBar1.Text = "No Accessible Objects Found.  Please investigate."
                Else
                    ' populate the treeview level 0 with all the AA objects
                    Dim myEnumerator As System.Collections.IEnumerator = m_msaaArraList.GetEnumerator()

                    While myEnumerator.MoveNext()
                        ' the role text for static text is "text", which is confusing with a textbox that has a role text of "editable text"
                        If myEnumerator.Current.Role = MsaaRoles.StaticText Then
                            Me.TreeView1.Nodes.Add(New TreeNode(myEnumerator.Current.Name + " [static text]"))
                        Else
                            Me.TreeView1.Nodes.Add(New TreeNode(myEnumerator.Current.Name + " [" + myEnumerator.Current.RoleText + "]"))
                        End If
                    End While

                    Me.StatusBar1.Text = "Ready"
                    Me.VerifyButton.Enabled = True
                End If
            End If
        End Sub

        Private Sub PictureBox1_Paint(ByVal sender As Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles PictureBox1.Paint
            If m_blnMouseDown = False Then
                ' Create image.
                Dim imageFile As Image = Image.FromFile("crosshairs.jpg")
                ' Draw image to screen.
                e.Graphics.DrawImage(imageFile, New PointF(0.0F, 0.0F))
            End If
        End Sub

        Private Sub ResetForm()
            ClearRect()
            Me.TreeView1.Nodes.Clear()
            Me.m_hasVerifiedThisSession = False
            Me.TextBoxPassed.Text = ""
            Me.TextBoxFailed.Text = ""
            Me.StatusBar1.Text = "Ready"
            Me.m_foundHwnd = 0
            Me.m_foundMsaaObject = Nothing
            Me.m_hasVerifiedThisSession = False
            Me.m_msaaArraList.Clear()
        End Sub

        Private Sub ClearRect()
            If Not m_foundMsaaObject Is Nothing Then
                NativeMethods.BitBlt(m_hDCScreen, m_foundMsaaObject.X - PenWidth, m_foundMsaaObject.Y - PenWidth, m_foundMsaaObject.Width + PenWidth * 2, m_foundMsaaObject.Height + PenWidth * 2, m_hDCScreenCompatible, 0, 0, SrcCopy)
                NativeMethods.SelectObject(m_hDCScreenCompatible, m_hDCOld)
                If Not m_hDCScreen.Equals(IntPtr.Zero) Then
                    NativeMethods.DeleteDC(m_hDCScreen)
                End If

                If Not m_hDCScreenCompatible.Equals(IntPtr.Zero) Then
                    NativeMethods.DeleteDC(m_hDCScreenCompatible)
                End If

                If Not m_hScreenCompatibleBmp.Equals(IntPtr.Zero) Then
                    NativeMethods.DeleteObject(m_hScreenCompatibleBmp)
                End If
            End If
        End Sub

        Private Sub DrawRect(ByVal Left As Integer, ByVal Top As Integer, ByVal Width As Integer, ByVal Height As Integer)
            Left = Left - PenWidth
            Top = Top - PenWidth
            Width = Width + PenWidth * 2
            Height = Height + PenWidth * 2

            m_hDCScreen = NativeMethods.GetDC(Nothing)
            Dim formGraphics As Graphics = Graphics.FromHdc(m_hDCScreen)

            m_hDCScreenCompatible = NativeMethods.CreateCompatibleDC(m_hDCScreen)
            m_hScreenCompatibleBmp = NativeMethods.CreateCompatibleBitmap(m_hDCScreen, Width, Height)
            m_hDCOld = NativeMethods.SelectObject(m_hDCScreenCompatible, m_hScreenCompatibleBmp)

            NativeMethods.BitBlt(m_hDCScreenCompatible, 0, 0, Width, Height, m_hDCScreen, Left, Top, SrcCopy)

            ' Create Pen and Rectangle 
            Dim blackPen As New Pen(Color.FromArgb(128, 0, 0, 0), PenWidth)
            Dim rect As New Rectangle(Left + PenWidth, Top + PenWidth, Width - PenWidth * 2, Height - PenWidth * 2)
            formGraphics.CompositingMode = Drawing2D.CompositingMode.SourceOver

            formGraphics.DrawRectangle(blackPen, rect)
        End Sub

#End Region

#Region "Private Methods"

        Private Sub VerifyNow()
            Me.Cursor = Cursors.WaitCursor
            Me.StatusBar1.Text = "Verifying... Please wait."
            m_hasVerifiedThisSession = True
            m_ops.VerifyMsaaObjects()
            Me.StatusBar1.Text = "Ready"
            Me.Cursor = Cursors.Default
            Me.VerifyButton.Enabled = False
        End Sub
#End Region

#Region "Event Handlers"
        Private Sub MenuItemAbout_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItemAbout.Click
            MessageBox.Show("MsaaVerify 1.0", "About", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1)
        End Sub

        Private Sub MenuItemHelpVerifications_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItemHelpVerifications.Click
            Dim helpVerificationsDlg As New HelpVerifications
            helpVerificationsDlg.ShowDialog()
        End Sub

        Private Sub MenuItemVerifyMsaa_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItemVerifyMsaa.Click
            VerifyNow()
        End Sub

        Private Sub treeView1_MouseDown(ByVal sender As Object, _
                ByVal e As System.Windows.Forms.MouseEventArgs) Handles TreeView1.MouseDown
            TreeView1.SelectedNode = TreeView1.GetNodeAt(e.X, e.Y)
        End Sub

        Protected Sub VerifyNow_OnClick(ByVal sender As System.Object, ByVal e As System.EventArgs)
            VerifyNow()
        End Sub

        Private Sub VerifyButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles VerifyButton.Click
            VerifyNow()
        End Sub

        Private Sub CrosshairsRadioButton_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CrosshairsRadioButton.CheckedChanged
            Me.HwndTextBox.ReadOnly = True
            Me.CaptureButton.Enabled = False
        End Sub

        Private Sub HwndRadioButton_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles HwndRadioButton.CheckedChanged
            Me.HwndTextBox.ReadOnly = False
            Me.CaptureButton.Enabled = True
        End Sub

        Private Sub CaptureButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CaptureButton.Click
            Dim hwnd As IntPtr
            Try
                hwnd = New IntPtr(CType(Me.HwndTextBox.Text, Integer))
                If m_foundMsaaObject.IsWindowValid() Then
                    ' create the accessible object by window
                    m_foundMsaaObject = New AccessibleObject(hwnd)
                    ResetForm()
                    PopulateTreeViewWithControls()
                Else
                    MsgBox("Could not find a valid window with HWND: " & Me.HwndTextBox.Text)
                End If
            Catch ex As System.InvalidCastException
                MsgBox("Message box must contain only integer values.")
            Catch ex As Exception
                MsgBox("Could not find a valid window with HWND: " & Me.HwndTextBox.ToString)
            End Try
        End Sub

        Private Sub ResetFormButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ResetFormButton.Click
            Me.ResetForm()
        End Sub
#End Region

        Private Function IsWin9x()
            Dim osInfo As OperatingSystem = Environment.OSVersion
            Return osInfo.Platform = PlatformID.Win32Windows And osInfo.Version.Minor <> 90
        End Function
    End Class
End Namespace
